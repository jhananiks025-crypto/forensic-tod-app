# Forensic Time-of-Death Estimation (prototype)

React + Vite + Tailwind frontend with a Python (FastAPI) analytics backend in `backend/`.
The app is an educational decision-support prototype. **No validated time-of-death model is connected**; nothing here estimates an
actual time of death. The supplied dataset is synthetic educational data.

## Run (two terminals, Node.js 18+ and Python 3.10+)
**1 – Backend**
```powershell
cd backend
python -m venv .venv ; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
# put your CSV at backend\data\forensic_tod_cleaned.csv
uvicorn app.main:app --reload --port 8000
```
**2 – Frontend** (project root)
```powershell
copy .env.example .env         # VITE_API_BASE_URL=http://localhost:8000
npm install
npm run dev
```
Open http://localhost:5173. Details, API reference and tests: `backend/README.md`.

## What the backend powers
* **Analytics & Charts** – summary cards, scene/year/month/location charts, temperature and PMI-label distributions, data quality,
  Year → Month → Case drill-down with breadcrumbs, a date-range filter (discovery_datetime, UTC, inclusive) and click-to-explore charts.
* **Overview** – live dataset figures (falls back to labelled sample data if the backend is unreachable).
* **Data Explorer** – shows the server dataset, its column mapping and validation, above the unchanged browser-side CSV checker.
* Case creation, Case Records, Time Interval Analysis, Model Evaluation and Reports are unchanged (still local-storage / no model).
