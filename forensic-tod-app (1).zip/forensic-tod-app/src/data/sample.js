// ALL DATA HERE IS SAMPLE / DEMONSTRATION DATA. Replace with API calls to a Python/PostgreSQL service later.
export const CATS = ['Indoor', 'Outdoor', 'Vehicle', 'Water-adjacent']
export const YEARS = [2018, 2019, 2020, 2021, 2022, 2023]
export const BINS = ['<0 °C', '0–10', '10–20', '20–30', '30+']
export const ROWS = YEARS.flatMap(y => CATS.flatMap((c, ci) => BINS.map((b, bi) => ({ year: y, cat: c, bin: b, n: ((y * 7 + ci * 5 + bi * 11) % 17) + 3 }))))
export const DATASETS = [
  { id: 'ds1', name: 'Sample Dataset A (demo)', records: 12480, valid: 11210, missing: 910, dupes: 360, outliers: 0, offset: 0 },
  { id: 'ds2', name: 'Sample Dataset B (demo)', records: 8350, valid: 7400, missing: 640, dupes: 310, outliers: 0, offset: 5 },
]
export const agg = (rows, key) => { const m = {}; rows.forEach(r => { m[r[key]] = (m[r[key]] || 0) + r.n }); return Object.entries(m).map(([name, value]) => ({ name, value })) }
export const ACTIVITY = [
  { caseId: 'FTE-DEMO-001', dataset: 'Sample Dataset A (demo)', date: '2026-09-28', records: 12480, status: 'Completed' },
  { caseId: 'FTE-DEMO-002', dataset: 'Sample Dataset B (demo)', date: '2026-09-30', records: 8350, status: 'Needs review' },
  { caseId: 'FTE-DEMO-003', dataset: 'Sample Dataset A (demo)', date: '2026-10-02', records: 12480, status: 'Completed' },
]
export const SEED_CASES = [
  { id: 'FTE-DEMO-001', title: 'Sample case – indoor discovery', discDate: '2026-09-20', discTime: '08:30', locCat: 'Residential', env: 'Indoor', locDesc: 'Sample description', lastAliveDate: '2026-09-19', lastAliveTime: '21:00', reportedDate: '2026-09-20', reportedTime: '08:45', tlSource: 'Witness statement', tlVerified: 'Unverified', temp: '21', unit: '°C', cond: 'Indoor climate-controlled', tempMode: 'Reported', obsDate: '2026-09-20', obsTime: '09:00', obsSource: 'Sample source', hasDataset: 'Yes', hasEnv: 'Yes', hasTimeline: 'Yes', examStatus: 'Not yet performed', notes: '', status: 'Analysed', created: '2026-09-20', demo: true },
  { id: 'FTE-DEMO-002', title: 'Sample case – outdoor draft', discDate: '2026-09-25', discTime: '06:10', locCat: 'Public space', env: 'Outdoor', locDesc: '', lastAliveDate: '', lastAliveTime: '', reportedDate: '', reportedTime: '', tlSource: 'Unknown', tlVerified: 'Unknown', temp: '', unit: '°C', cond: '', tempMode: '', obsDate: '', obsTime: '', obsSource: '', hasDataset: 'Unknown', hasEnv: 'No', hasTimeline: 'No', examStatus: 'Unknown', notes: '', status: 'Draft', created: '2026-09-25', demo: true },
]
