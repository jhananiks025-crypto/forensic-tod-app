import { useEffect, useState, useCallback } from 'react'
// Runs `fn(signal)` whenever `deps` change; aborts the previous request so stale responses never overwrite newer ones.
export function useApi(fn, deps, enabled = true) {
  const [state, setState] = useState({ data: null, error: null, loading: enabled })
  const [nonce, setNonce] = useState(0)
  useEffect(() => {
    if (!enabled) return
    const ac = new AbortController()
    setState(s => ({ data: s.data, error: null, loading: true }))
    fn({ signal: ac.signal }).then(data => setState({ data, error: null, loading: false }))
      .catch(error => { if (error.name !== 'AbortError') setState({ data: null, error, loading: false }) })
    return () => ac.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce, enabled])
  const reload = useCallback(() => setNonce(n => n + 1), [])
  return { ...state, reload }
}
