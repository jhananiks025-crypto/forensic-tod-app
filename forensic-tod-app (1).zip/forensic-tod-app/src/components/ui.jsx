import { useEffect } from 'react'
import { X, Loader2, Inbox } from 'lucide-react'
export const tip = { contentStyle: { background: '#111827', border: '1px solid #263449', borderRadius: 8, color: '#F8FAFC' }, labelStyle: { color: '#94A3B8' } }
export const COLORS = ['#38BDF8', '#34D399', '#FBBF24', '#94A3B8']
export const Card = ({ className = '', children }) => <div className={`rounded-2xl border border-line bg-card p-5 ${className}`}>{children}</div>
const tones = { ok: 'bg-secondary/15 text-secondary', warn: 'bg-warning/15 text-warning', info: 'bg-primary/15 text-primary', mute: 'bg-line text-muted' }
export const Badge = ({ tone = 'mute', children }) => <span className={`inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>
export const statusTone = s => ({ Draft: 'mute', Submitted: 'info', Analysed: 'ok', Completed: 'ok', 'Needs review': 'warn' }[s] || 'mute')
export const Sample = ({ children = 'Sample data' }) => <Badge tone="warn">{children}</Badge>
const bv = { primary: 'bg-primary text-bg hover:bg-primary/90', ghost: 'border border-line text-ink hover:bg-line/50', danger: 'bg-red-500/15 text-red-300 hover:bg-red-500/25' }
export const Btn = ({ v = 'primary', className = '', ...p }) => <button type="button" className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition disabled:opacity-50 ${bv[v]} ${className}`} {...p} />
export const PageHead = ({ title, children }) => <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold">{title}</h2><div className="flex flex-wrap gap-2">{children}</div></div>
export const Empty = ({ title, text, children }) => <div className="flex flex-col items-center gap-2 py-10 text-center"><Inbox className="text-muted" /><p className="font-medium">{title}</p><p className="max-w-md text-sm text-muted">{text}</p>{children}</div>
export const Spinner = ({ text = 'Working…' }) => <div role="status" className="flex items-center justify-center gap-2 py-8 text-sm text-muted"><Loader2 className="animate-spin text-primary" size={18} />{text}</div>
export const Alert = ({ tone = 'warn', children }) => <div role="alert" className={`rounded-lg border px-3 py-2 text-sm ${tone === 'err' ? 'border-red-400/40 bg-red-500/10 text-red-200' : tone === 'ok' ? 'border-secondary/40 bg-secondary/10 text-secondary' : 'border-warning/40 bg-warning/10 text-warning'}`}>{children}</div>
export function Modal({ title, onClose, children, footer }) {
  useEffect(() => { const k = e => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  return <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={title} className="max-h-[85vh] w-full max-w-lg overflow-auto rounded-2xl border border-line bg-card p-5" onClick={e => e.stopPropagation()}>
      <div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">{title}</h3><button aria-label="Close dialog" onClick={onClose}><X size={18} /></button></div>
      {children}{footer && <div className="mt-4 flex justify-end gap-2">{footer}</div>}</div></div>
}
export const Confirm = ({ title, text, yes = 'Confirm', danger, onYes, onNo }) => <Modal title={title} onClose={onNo} footer={<><Btn v="ghost" onClick={onNo}>Cancel</Btn><Btn v={danger ? 'danger' : 'primary'} onClick={onYes}>{yes}</Btn></>}><p className="text-sm text-muted">{text}</p></Modal>
export const Bar = ({ value }) => <div className="h-2 w-full rounded-full bg-line" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}><div className="h-2 rounded-full bg-gradient-to-r from-primary to-secondary" style={{ width: value + '%' }} /></div>
export const Table = ({ head, children }) => <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-muted"><tr>{head.map(h => <th key={h} className="whitespace-nowrap border-b border-line px-3 py-2 font-medium">{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div>
export const Td = ({ children }) => <td className="whitespace-nowrap border-b border-line/60 px-3 py-2">{children}</td>
