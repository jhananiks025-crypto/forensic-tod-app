import { useState, useEffect } from 'react'
import { Download, ChevronLeft, ChevronRight, ArrowUp, ArrowDown } from 'lucide-react'
import { Card, Alert, Empty, Spinner, Btn, Td, Badge } from '../ui'
import { useApi } from '../../hooks/useApi'
import { api } from '../../utils/api'
import { download } from '../../utils/csv'
import { CaseModal, pretty, fmt } from './parts'

const PAGE = 15
const COLS = [['case_id', 'Case ID'], ['discovery_datetime', 'Discovery (UTC)'], ['scene_type', 'Scene'], ['location_category', 'Location'], ['ambient_temperature_c', 'Ambient °C'], ['postmortem_interval_hours', 'PMI label (h)'], ['data_quality_status', 'Quality']]

export default function RecordsPanel({ params, heading }) {
  const [page, setPage] = useState(1), [sort, setSort] = useState({ by: 'discovery_datetime', dir: 'asc' }), [open, setOpen] = useState(null), [exp, setExp] = useState({ busy: false, err: '' })
  const key = JSON.stringify(params)
  useEffect(() => { setPage(1) }, [key])
  const res = useApi(o => api.cases({ ...params, page, page_size: PAGE, sort_by: sort.by, sort_dir: sort.dir }, o), [key, page, sort.by, sort.dir])
  const d = res.data?.data
  const toggle = by => setSort(s => s.by === by ? { by, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { by, dir: 'asc' })
  const doExport = async () => {
    setExp({ busy: true, err: '' })
    try { download('forensic-tod-cases-filtered.csv', await api.exportCases(params)); setExp({ busy: false, err: '' }) }
    catch (e) { setExp({ busy: false, err: e.message }) }
  }
  return <Card>
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
      <div><h3 className="font-medium">{heading}</h3><p className="text-sm text-muted">{d ? `${d.total.toLocaleString()} matching record${d.total === 1 ? '' : 's'}` : ' '}</p></div>
      <Btn v="ghost" onClick={doExport} disabled={exp.busy || !d?.total}><Download size={16} />{exp.busy ? 'Exporting…' : 'Export filtered CSV'}</Btn></div>
    {exp.err && <div className="mb-2"><Alert tone="err">{exp.err}</Alert></div>}
    {res.error ? <Alert tone="err">{res.error.message}</Alert>
      : res.loading && !d ? <Spinner text="Loading records…" />
      : !d?.total ? <Empty title="No matching records" text="Nothing matches the current date range, drill-down and chart selections. Adjust or reset the filters." />
      : <div className={res.loading ? 'opacity-50' : ''}>
        <div className="overflow-x-auto"><table className="w-full text-left text-sm">
          <thead className="text-muted"><tr>
            {COLS.map(([k, l]) => <th key={k} aria-sort={sort.by === k ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none'} className="whitespace-nowrap border-b border-line px-3 py-2 font-medium">
              <button className="inline-flex items-center gap-1 hover:text-ink" onClick={() => toggle(k)}>{l}{sort.by === k && (sort.dir === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}</button></th>)}
            <th className="whitespace-nowrap border-b border-line px-3 py-2 font-medium">Details</th></tr></thead>
          <tbody>{d.items.map(r => <tr key={r.case_id}>
            <Td>{r.case_id}</Td><Td>{(r.discovery_datetime || '').replace('T', ' ').replace('Z', '')}</Td><Td>{pretty(r.scene_type)}</Td><Td>{pretty(r.location_category)}</Td>
            <Td>{fmt(r.ambient_temperature_c)}</Td><Td>{fmt(r.postmortem_interval_hours, 2)}</Td><Td><Badge tone={r.data_quality_status === 'validated_complete' ? 'ok' : 'mute'}>{pretty(r.data_quality_status)}</Badge></Td>
            <Td><Btn v="ghost" className="!py-1" onClick={() => setOpen(r.case_id)}>View</Btn></Td></tr>)}</tbody>
        </table></div>
        <div className="mt-3 flex items-center justify-between text-sm text-muted">
          <span>Page {d.page} of {d.total_pages}</span>
          <div className="flex gap-2"><Btn v="ghost" className="!py-1" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft size={16} />Prev</Btn>
            <Btn v="ghost" className="!py-1" disabled={page >= d.total_pages} onClick={() => setPage(p => p + 1)}>Next<ChevronRight size={16} /></Btn></div></div></div>}
    {open && <CaseModal id={open} onClose={() => setOpen(null)} />}
  </Card>
}
