import { X, RefreshCw } from 'lucide-react'
import { Card, Badge, Alert, Empty, Spinner, Btn, Modal } from '../ui'
import { useApi } from '../../hooks/useApi'
import { api } from '../../utils/api'

export const pretty = s => String(s ?? '').replace(/_/g, ' ')
export const fmt = (v, d = 1) => v === null || v === undefined ? '—' : Number(v).toLocaleString(undefined, { maximumFractionDigits: d })

// Chart card with loading / error / empty / unavailable states. `res` is the useApi result.
export function LiveChart({ title, res, note, isEmpty, emptyText = 'No records match the current filters.', unavailable, badge = 'Live data', children, className = '' }) {
  const body = res.error
    ? <div className="space-y-2"><Alert tone="err">{res.error.message}</Alert><Btn v="ghost" className="!py-1" onClick={res.reload}><RefreshCw size={14} />Retry</Btn></div>
    : unavailable ? <Empty title="Chart unavailable" text={unavailable} />
    : res.loading && !res.data ? <Spinner text="Loading…" />
    : isEmpty ? <Empty title="No data to show" text={emptyText} />
    : <div className={`h-64 ${res.loading ? 'opacity-50 transition' : ''}`} aria-busy={res.loading}>{children}</div>
  return <Card className={className}>
    <div className="mb-3 flex items-start justify-between gap-2"><h3 className="font-medium">{title}</h3><Badge tone="info">{badge}</Badge></div>
    {body}{note && !res.error && <p className="mt-2 text-xs text-muted">{note}</p>}
  </Card>
}

export const Stat = ({ label, value, sub, res }) => <Card>
  <p className="text-sm text-muted">{label}</p>
  <p className="mt-1 text-2xl font-semibold">{res?.loading && !res?.data ? '…' : res?.error ? '—' : value}</p>
  {sub && <p className="mt-1 text-xs text-muted">{sub}</p>}
</Card>

export const Chip = ({ children, onClear }) => <span className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs text-primary">
  {children}<button aria-label="Remove filter" onClick={onClear} className="rounded-full hover:bg-primary/20"><X size={12} /></button></span>

const LABELS = { case_id: 'Case ID', discovery_datetime: 'Discovery (UTC)', last_known_alive_datetime: 'Last known alive (UTC)', reported_datetime: 'Reported (UTC)', observation_datetime: 'Observation (UTC)', reference_estimated_death_datetime: 'Reference death time (label)', postmortem_interval_hours: 'PMI reference label (h)', ambient_temperature_c: 'Ambient temperature (°C)', body_temperature_c: 'Body temperature (°C)', relative_humidity_pct: 'Relative humidity (%)' }
const label = k => LABELS[k] || pretty(k).replace(/^./, c => c.toUpperCase())

export function CaseModal({ id, onClose }) {
  const res = useApi(o => api.caseById(id, o), [id])
  const d = res.data?.data
  return <Modal title={`Case ${id}`} onClose={onClose}>
    {res.loading && <Spinner text="Loading case…" />}
    {res.error && <Alert tone="err">{res.error.message}</Alert>}
    {d && <>
      {d.is_synthetic && <div className="mb-2"><Badge tone="warn">Synthetic educational data</Badge></div>}
      <p className="mb-3 text-xs text-muted">{d.notice}</p>
      <dl className="space-y-1 text-sm">{Object.entries(d.fields).map(([k, v]) => <div key={k} className="flex justify-between gap-4 border-b border-line/40 py-1">
        <dt className="text-muted">{label(k)}{d.target_derived_columns.includes(k) && <span className="ml-1 text-warning">(target-derived)</span>}</dt>
        <dd className="text-right">{v === null || v === '' ? 'Not provided' : pretty(v)}</dd></div>)}</dl></>}
  </Modal>
}
