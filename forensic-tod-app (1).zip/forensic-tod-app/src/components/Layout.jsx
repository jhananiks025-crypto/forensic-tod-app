import { useState, useEffect } from 'react'
import { NavLink, Outlet, useLocation, useNavigate, Link } from 'react-router-dom'
import { Fingerprint, LayoutDashboard, FilePlus2, FolderOpen, Database, Clock, BarChart3, FlaskConical, FileText, Info, Bell, Menu, Search, User } from 'lucide-react'
const NAV = [['/app', 'Overview', LayoutDashboard], ['/app/new', 'Create New Case', FilePlus2], ['/app/records', 'Case Records', FolderOpen], ['/app/explorer', 'Data Explorer', Database], ['/app/analysis', 'Time Interval Analysis', Clock], ['/app/analytics', 'Analytics & Charts', BarChart3], ['/app/models', 'Model Evaluation', FlaskConical], ['/app/reports', 'Reports', FileText], ['/app/about', 'About Project', Info]]
export default function Layout() {
  const [wide, setWide] = useState(true), [mob, setMob] = useState(false), [bell, setBell] = useState(false), [q, setQ] = useState('')
  const { pathname } = useLocation(), nav = useNavigate()
  useEffect(() => { setMob(false); setBell(false) }, [pathname])
  const title = (NAV.find(n => n[0] === pathname) || [0, pathname.includes('results') ? 'Case Analysis Results' : 'Dashboard'])[1]
  const links = labels => NAV.map(([to, l, I]) => <NavLink key={to} to={to} end={to === '/app'} title={l} className={({ isActive }) => `flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${isActive ? 'bg-primary/15 text-primary' : 'text-muted hover:bg-line/50 hover:text-ink'}`}><I size={18} className="shrink-0" />{labels && l}</NavLink>)
  const brand = labels => <Link to="/" className="mb-4 flex items-center gap-2 px-2 font-semibold"><Fingerprint className="text-primary" />{labels && 'Forensic TOD'}</Link>
  return <div className="flex min-h-screen">
    <aside className={`no-print sticky top-0 hidden h-screen shrink-0 flex-col border-r border-line bg-side p-3 transition-all md:flex ${wide ? 'w-60' : 'w-16'}`}>{brand(wide)}<nav className="flex flex-col gap-1">{links(wide)}</nav></aside>
    {mob && <div className="no-print fixed inset-0 z-40 md:hidden"><div className="absolute inset-0 bg-black/60" onClick={() => setMob(false)} /><aside className="relative h-full w-64 bg-side p-3">{brand(true)}<nav className="flex flex-col gap-1">{links(true)}</nav></aside></div>}
    <div className="min-w-0 flex-1">
      <header className="no-print sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur">
        <button aria-label="Toggle sidebar" className="rounded-lg p-2 hover:bg-line/50" onClick={() => window.innerWidth < 768 ? setMob(v => !v) : setWide(v => !v)}><Menu size={20} /></button>
        <h1 className="hidden text-lg font-semibold sm:block">{title}</h1>
        <form className="relative ml-auto w-full max-w-xs" onSubmit={e => { e.preventDefault(); nav('/app/records?q=' + encodeURIComponent(q)) }}>
          <Search size={16} className="absolute left-3 top-2.5 text-muted" /><input aria-label="Search case ID" value={q} onChange={e => setQ(e.target.value)} placeholder="Search case ID…" className="w-full rounded-lg border border-line bg-card py-2 pl-9 pr-3 text-sm" /></form>
        <div className="relative"><button aria-label="Notifications" className="rounded-lg p-2 hover:bg-line/50" onClick={() => setBell(v => !v)}><Bell size={20} /></button>
          {bell && <div className="absolute right-0 mt-2 w-60 rounded-xl border border-line bg-card p-3 text-sm text-muted">No notifications. Alerts are not connected in this prototype.</div>}</div>
        <div title="User profile placeholder" className="rounded-full bg-line p-2"><User size={18} /></div>
      </header>
      <main className="p-4 md:p-6"><Outlet /></main>
    </div></div>
}
