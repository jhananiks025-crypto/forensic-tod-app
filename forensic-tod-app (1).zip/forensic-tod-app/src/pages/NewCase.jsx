import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Card, Btn, Alert, Spinner, Confirm, Bar, Table, Td, PageHead } from '../components/ui'
import { useCases, saveCase, emptyCase, validate, completeness, summaryRows, today } from '../utils/store'
import { runDemoAnalysis } from '../utils/analysis'
const STEPS = ['A. Case identification', 'B. Timeline', 'C. Environment', 'D. Data availability', 'E. Review']
const STEP = { id: 0, title: 0, discDate: 0, discTime: 0, locCat: 0, env: 0, lastAliveDate: 1, reportedDate: 1, temp: 2, obsDate: 2 }
const inp = 'w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary'
const YN = ['Yes', 'No', 'Unknown']
function F({ name, label, value, onChange, error, type = 'text', opts, hint, req }) {
  const id = 'f-' + name, p = { id, value, 'aria-invalid': !!error, className: inp, onChange: e => onChange(e.target.value) }
  return <div><label htmlFor={id} className="mb-1 block text-sm">{label}{req && <span className="text-warning"> *</span>}</label>
    {opts ? <select {...p}><option value="">{req ? 'Select…' : 'Unknown / not provided'}</option>{opts.map(o => <option key={o}>{o}</option>)}</select>
      : type === 'textarea' ? <textarea rows={3} {...p} /> : <input type={type} {...p} />}
    {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}{error && <p role="alert" className="mt-1 text-xs text-red-300">{error}</p>}</div>
}
export default function NewCase() {
  const nav = useNavigate(), [sp] = useSearchParams(), cases = useCases(), editId = sp.get('edit')
  const [f, setF] = useState(() => { const x = cases.find(c => c.id === editId); if (x) return { ...emptyCase(), ...x }; try { const d = JSON.parse(localStorage.getItem('fte_draft')); if (d) return d } catch {} return emptyCase() })
  const [err, setErr] = useState({}), [step, setStep] = useState(0), [msg, setMsg] = useState(''), [ask, setAsk] = useState(false), [busy, setBusy] = useState(false)
  useEffect(() => { if (!editId) try { localStorage.setItem('fte_draft', JSON.stringify(f)) } catch {} }, [f, editId])
  const fld = (n, l, o = {}) => <F name={n} label={l} value={f[n]} onChange={v => setF(p => ({ ...p, [n]: v }))} error={err[n]} {...o} />
  const created = () => cases.find(c => c.id === f.id)?.created || today()
  const check = () => { const e = validate(f); setErr(e); const k = Object.keys(e)[0]; if (k) { setStep(STEP[k] ?? 0); setMsg('Fix the highlighted fields to continue.'); return false } setMsg(''); return true }
  const draft = () => { const e = {}; if (!f.id.trim()) e.id = 'Case ID is required.'; if (!f.title.trim()) e.title = 'A draft needs a reference title.'; setErr(e); if (Object.keys(e).length) { setStep(0); return setMsg('A draft needs a case ID and title.') } saveCase({ ...f, status: 'Draft', created: created() }); setMsg('Draft saved to local demo storage.') }
  const clear = () => { setF(emptyCase()); setErr({}); setStep(0); setMsg('Form cleared.') }
  const go = async () => { setAsk(false); setBusy(true); const base = { ...f, created: created() }; saveCase({ ...base, status: 'Submitted' }); const a = await runDemoAnalysis(base); saveCase({ ...base, status: 'Analysed', analysis: a }); try { localStorage.removeItem('fte_draft') } catch {} nav('/app/results/' + f.id) }
  if (busy) return <Card><Spinner text="Analysing case with the demonstration pipeline…" /></Card>
  return <div className="mx-auto max-w-3xl">
    <PageHead title={editId ? 'Edit Draft Case' : 'Create New Case'} />
    <p className="mb-4 text-sm text-muted">Do not enter real personal or sensitive investigation data. Data stays in this browser only. Fields marked * are required; leave anything unavailable blank.</p>
    <div className="mb-4 flex flex-wrap gap-2">{STEPS.map((s, i) => <button key={s} type="button" aria-current={i === step} onClick={() => setStep(i)} className={`rounded-lg px-3 py-1.5 text-sm ${i === step ? 'bg-primary text-bg' : 'border border-line text-muted hover:bg-line/50'}`}>{s}</button>)}</div>
    {msg && <div className="mb-3"><Alert tone={msg.includes('saved') || msg.includes('cleared') ? 'ok' : 'warn'}>{msg}</Alert></div>}
    <Card><div className="grid gap-4 sm:grid-cols-2">
      {step === 0 && <>{fld('id', 'Case ID', { req: 1, hint: 'Demo ID generated automatically; you may edit it.' })}{fld('title', 'Case reference title', { req: 1 })}{fld('discDate', 'Date of discovery', { type: 'date', req: 1 })}{fld('discTime', 'Time of discovery', { type: 'time', req: 1 })}
        {fld('locCat', 'Location category', { req: 1, opts: ['Residential', 'Commercial', 'Public space', 'Rural / open land', 'Vehicle', 'Other'] })}{fld('env', 'Indoor or outdoor', { req: 1, opts: ['Indoor', 'Outdoor'] })}<div className="sm:col-span-2">{fld('locDesc', 'General location description', { type: 'textarea', hint: 'Keep it general – no addresses or names.' })}</div></>}
      {step === 1 && <><p className="text-sm text-muted sm:col-span-2">Discovery time (section A) is not the time of death. Leave unknown fields blank.</p>{fld('lastAliveDate', 'Last known alive – date', { type: 'date' })}{fld('lastAliveTime', 'Last known alive – time', { type: 'time' })}{fld('reportedDate', 'Incident reported – date', { type: 'date' })}{fld('reportedTime', 'Incident reported – time', { type: 'time' })}
        {fld('tlSource', 'Source of timeline information', { opts: ['Witness statement', 'Digital record', 'Official record', 'Other', 'Unknown'] })}{fld('tlVerified', 'Information verified?', { opts: ['Verified', 'Unverified', 'Unknown'] })}</>}
      {step === 2 && <>{fld('temp', 'Ambient temperature', { type: 'number', hint: 'Leave blank if unavailable. 0 is a real reading, not "unknown".' })}{fld('unit', 'Measurement unit', { opts: ['°C', '°F'], req: 1 })}
        {fld('cond', 'Environmental conditions', { opts: ['Dry', 'Humid', 'Rainy', 'Windy', 'Indoor climate-controlled', 'Other'] })}{fld('tempMode', 'Measured or reported', { opts: ['Measured', 'Reported'] })}{fld('obsDate', 'Observation date', { type: 'date' })}{fld('obsTime', 'Observation time', { type: 'time' })}{fld('obsSource', 'Source of measurement')}</>}
      {step === 3 && <>{fld('hasDataset', 'Historical dataset available?', { opts: YN })}{fld('hasEnv', 'Environmental measurements available?', { opts: YN })}{fld('hasTimeline', 'Timeline information available?', { opts: YN })}{fld('examStatus', 'Professional forensic examination status', { opts: ['Not yet performed', 'In progress', 'Completed', 'Unknown'] })}<div className="sm:col-span-2">{fld('notes', 'Additional notes on data availability', { type: 'textarea' })}</div></>}
    </div>
    {step === 4 && <div className="space-y-3"><div><p className="mb-1 text-sm text-muted">Data completeness: {completeness(f)}%</p><Bar value={completeness(f)} /></div><Table head={['Field', 'Value']}>{summaryRows({ ...f, status: 'Not yet submitted' }).map(([k, v]) => <tr key={k}><Td>{k}</Td><Td>{v}</Td></tr>)}</Table></div>}
    </Card>
    <div className="mt-4 flex flex-wrap gap-2"><Btn v="ghost" onClick={() => setStep(s => Math.max(0, s - 1))} disabled={step === 0}>Back</Btn><Btn v="ghost" onClick={() => setStep(s => Math.min(4, s + 1))} disabled={step === 4}>Next</Btn>
      <span className="grow" /><Btn v="ghost" onClick={draft}>Save Draft</Btn><Btn v="ghost" onClick={clear}>Clear Form</Btn><Btn v="ghost" onClick={() => check() && setStep(4)}>Review Case</Btn><Btn onClick={() => check() && setAsk(true)}>Submit for Analysis</Btn></div>
    {ask && <Confirm title="Submit for analysis?" text="The case will be saved locally and run through the demonstration analysis. No death-time estimate will be generated." yes="Submit" onYes={go} onNo={() => setAsk(false)} />}
  </div>
}
