import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Card, Btn, Alert, Spinner, Badge, Bar, Empty, PageHead } from '../components/ui'
import { useCases, validate, completeness } from '../utils/store'
import { requiredInputs, runDemoAnalysis, MSG_UNAVAILABLE } from '../utils/analysis'
import { DATASETS } from '../data/sample'
const sel = 'rounded-lg border border-line bg-card px-3 py-2 text-sm'
export default function Analysis() {
  const cases = useCases(), [id, setId] = useState(cases[0]?.id || ''), [ds, setDs] = useState(DATASETS[0].id), [busy, setBusy] = useState(false), [res, setRes] = useState(null), [msg, setMsg] = useState('')
  const c = cases.find(x => x.id === id)
  const run = async () => {
    setRes(null); setMsg('')
    if (!c) return setMsg('Select a case first.')
    const e = validate(c); if (Object.keys(e).length) return setMsg('This case has validation issues: ' + Object.values(e).join(' '))
    setBusy(true); setRes(await runDemoAnalysis(c, ds)); setBusy(false)
  }
  if (!cases.length) return <Card><Empty title="No cases yet" text="Create a case to run the demonstration analysis."><Link className="text-primary" to="/app/new">Create new case</Link></Empty></Card>
  const req = c ? requiredInputs(c) : []
  return <div className="space-y-4">
    <PageHead title="Time Interval Analysis" />
    <Alert>Demonstration mode: no validated prediction model is connected, so no death-time estimate is produced.</Alert>
    <Card><div className="flex flex-wrap items-end gap-3">
      <label className="text-sm">Case<select value={id} onChange={e => { setId(e.target.value); setRes(null); setMsg('') }} className={sel + ' ml-2'}>{cases.map(x => <option key={x.id} value={x.id}>{x.id} – {x.title}</option>)}</select></label>
      <label className="text-sm">Dataset<select value={ds} onChange={e => setDs(e.target.value)} className={sel + ' ml-2'}>{DATASETS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
      <Btn onClick={run} disabled={busy}>Run Analysis</Btn></div></Card>
    {msg && <Alert tone="err">{msg}</Alert>}
    {c && <div className="grid gap-4 lg:grid-cols-2">
      <Card><h3 className="mb-2 font-medium">Input availability</h3><ul className="space-y-1 text-sm">{req.map(([l, ok]) => <li key={l} className="flex justify-between"><span>{l}</span><Badge tone={ok ? 'ok' : 'warn'}>{ok ? 'Available' : 'Missing'}</Badge></li>)}</ul></Card>
      <Card><h3 className="mb-2 font-medium">Timeline and environment</h3><p className="text-sm text-muted">Last known alive: {c.lastAliveDate ? `${c.lastAliveDate} ${c.lastAliveTime}` : 'Unknown'}<br />Discovery: {c.discDate} {c.discTime}<br />Ambient temperature: {c.temp === '' ? 'Not provided' : `${c.temp} ${c.unit} (${c.tempMode || 'source type unknown'})`}</p></Card></div>}
    {busy && <Card><Spinner text="Checking inputs and running demonstration analysis…" /></Card>}
    {res && <Card><div className="flex items-center justify-between"><h3 className="font-medium">Analysis status</h3><Badge tone="ok">Completed (demonstration)</Badge></div>
      <p className="mt-2 text-sm">{res.message}</p><p className="mt-1 text-sm text-muted">{MSG_UNAVAILABLE}</p>
      <p className="mt-3 text-sm">Data completeness: {completeness(c)}%</p><Bar value={completeness(c)} />
      {res.missing.length > 0 && <p className="mt-2 text-sm text-muted">Missing inputs: {res.missing.join(', ')}.</p>}
      <Link to={`/app/results/${c.id}`} className="mt-3 inline-block text-sm text-primary">Open full results</Link></Card>}
  </div>
}
