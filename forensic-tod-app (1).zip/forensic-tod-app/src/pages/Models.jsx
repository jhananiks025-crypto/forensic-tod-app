import { Card, Badge, Alert, PageHead, Empty } from '../components/ui'
const rows = [['Model name', 'None connected'], ['Model version', 'Not available'], ['Dataset information', 'No evaluation dataset linked'], ['Evaluation status', 'Not evaluated'], ['Training / testing split', 'Not evaluated']]
export default function Models() {
  return <div className="space-y-4">
    <PageHead title="Model Evaluation" />
    <Alert>No validated prediction model is connected.</Alert>
    <div className="grid gap-4 lg:grid-cols-2">
      <Card><h3 className="mb-3 font-medium">Model details</h3><dl className="space-y-2 text-sm">{rows.map(([k, v]) => <div key={k} className="flex justify-between"><dt className="text-muted">{k}</dt><dd><Badge>{v}</Badge></dd></div>)}</dl></Card>
      <Card><h3 className="mb-3 font-medium">Metrics</h3><div className="grid grid-cols-3 gap-3 text-center">{['MAE', 'RMSE', 'R²'].map(m => <div key={m} className="rounded-xl border border-line p-3"><p className="text-xs text-muted">{m}</p><p className="mt-1 text-sm font-medium">Not evaluated</p></div>)}</div></Card></div>
    <Card><h3 className="mb-2 font-medium">Actual vs predicted</h3><Empty title="No evaluation data" text="This chart appears only after a real evaluation is run on held-out data." /></Card>
    <Card><h3 className="mb-2 font-medium">Limitations and validation notes</h3><ul className="list-disc space-y-1 pl-5 text-sm text-muted"><li>Accuracy on one dataset does not establish forensic reliability.</li><li>Any future model needs independent validation, documented uncertainty and expert review.</li><li>Demonstration values are never shown here as evaluation results.</li></ul></Card>
  </div>
}
