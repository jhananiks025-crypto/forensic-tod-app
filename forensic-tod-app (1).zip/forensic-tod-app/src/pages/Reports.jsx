import { useState } from 'react'
import { Printer, Download } from 'lucide-react'
import { Card, Btn, Empty, PageHead, Badge } from '../components/ui'
import { useCases, completeness, summaryRows } from '../utils/store'
import { requiredInputs, MSG_UNAVAILABLE } from '../utils/analysis'
import { DATASETS } from '../data/sample'
import { toCSV, download } from '../utils/csv'
import { DISCLAIMER } from './Landing'
const SECTIONS = ['Case reference', 'Input information summary', 'Dataset information', 'Data completeness', 'Data quality findings', 'Analysis status', 'Model evaluation status', 'Uncertainty and limitations', 'Professional review disclaimer']
export default function Reports() {
  const cases = useCases(), [id, setId] = useState(cases[0]?.id || ''), [on, setOn] = useState(SECTIONS)
  const c = cases.find(x => x.id === id), d = DATASETS[0]
  if (!c) return <Card><Empty title="No cases available" text="Create a case before generating a report." /></Card>
  const has = s => on.includes(s), toggle = s => setOn(o => o.includes(s) ? o.filter(x => x !== s) : [...o, s])
  const Sec = ({ t, children }) => has(t) ? <section className="mb-4"><h3 className="mb-1 font-semibold">{t}</h3>{children}</section> : null
  return <div className="space-y-4">
    <PageHead title="Reports"><Btn v="ghost" onClick={() => download(`${c.id}-report.csv`, toCSV([['Section', 'Content'], ...summaryRows(c), ['Analysis', MSG_UNAVAILABLE], ['Disclaimer', DISCLAIMER]]))}><Download size={16} />Download CSV summary</Btn><Btn onClick={() => window.print()}><Printer size={16} />Print / Save as PDF</Btn></PageHead>
    <Card className="no-print"><label className="text-sm">Case <select value={id} onChange={e => setId(e.target.value)} className="ml-2 rounded-lg border border-line bg-bg px-3 py-2 text-sm">{cases.map(x => <option key={x.id} value={x.id}>{x.id} – {x.title}</option>)}</select></label>
      <fieldset className="mt-3 grid gap-1 sm:grid-cols-3"><legend className="mb-1 text-sm text-muted">Report sections</legend>{SECTIONS.map(s => <label key={s} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={has(s)} onChange={() => toggle(s)} />{s}</label>)}</fieldset></Card>
    <Card className="print-area"><h2 className="text-lg font-semibold">Forensic Time-of-Death Estimation – Case analysis summary</h2>
      <p className="mb-4 text-xs text-muted">Educational prototype summary – not an official forensic report. {c.demo && <Badge tone="warn">Generated from sample information</Badge>}</p>
      <Sec t="Case reference"><p className="text-sm">{c.id} – {c.title}</p></Sec>
      <Sec t="Input information summary"><dl className="grid gap-x-6 text-sm sm:grid-cols-2">{summaryRows(c).map(([k, v]) => <div key={k} className="flex justify-between gap-3 border-b border-line/50 py-0.5"><dt className="text-muted">{k}</dt><dd>{v}</dd></div>)}</dl></Sec>
      <Sec t="Dataset information"><p className="text-sm">{d.name}: {d.records.toLocaleString()} records (sample figures).</p></Sec>
      <Sec t="Data completeness"><p className="text-sm">{completeness(c)}% of key fields provided.</p></Sec>
      <Sec t="Data quality findings"><p className="text-sm">Missing required inputs: {requiredInputs(c).filter(x => !x[1]).map(x => x[0]).join(', ') || 'none'}.</p></Sec>
      <Sec t="Analysis status"><p className="text-sm">{c.status}. {MSG_UNAVAILABLE}</p></Sec>
      <Sec t="Model evaluation status"><p className="text-sm">No validated prediction model is connected. Not evaluated.</p></Sec>
      <Sec t="Uncertainty and limitations"><p className="text-sm">Sample data, local storage and demonstration logic only. No estimate of the time of death is made.</p></Sec>
      <Sec t="Professional review disclaimer"><p className="text-sm">{DISCLAIMER}</p></Sec></Card>
  </div>
}
