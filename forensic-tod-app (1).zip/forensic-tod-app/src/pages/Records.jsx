import { useState, useMemo, useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Eye, Pencil, Trash2, Download, ChevronLeft, ChevronRight } from 'lucide-react'
import { Card, Badge, Btn, Empty, Alert, Table, Td, Modal, Confirm, PageHead, statusTone } from '../components/ui'
import { useCases, deleteCase, completeness, summaryRows } from '../utils/store'
import { toCSV, download } from '../utils/csv'
const COLS = [['id', 'Case ID'], ['title', 'Reference Title'], ['discDate', 'Discovery Date'], ['discTime', 'Discovery Time'], ['comp', 'Data Completeness'], ['status', 'Analysis Status'], ['created', 'Created Date']]
export default function Records() {
  const cases = useCases(), [sp] = useSearchParams()
  const [q, setQ] = useState(sp.get('q') || ''), [st, setSt] = useState('All'), [key, setKey] = useState('created'), [dir, setDir] = useState(-1), [pg, setPg] = useState(0), [view, setView] = useState(null), [del, setDel] = useState(null)
  useEffect(() => { setQ(sp.get('q') || ''); setPg(0) }, [sp])
  const rows = useMemo(() => cases.filter(c => c.id.toLowerCase().includes(q.toLowerCase()) && (st === 'All' || c.status === st)).map(c => ({ ...c, comp: completeness(c) })).sort((a, b) => { const x = a[key] ?? '', y = b[key] ?? ''; return (x > y ? 1 : x < y ? -1 : 0) * dir }), [cases, q, st, key, dir])
  const pages = Math.max(1, Math.ceil(rows.length / 5)), cur = Math.min(pg, pages - 1), page = rows.slice(cur * 5, cur * 5 + 5)
  const sort = k => { if (k === key) setDir(-dir); else { setKey(k); setDir(1) } }
  const exp = () => download('case-records.csv', toCSV([COLS.map(c => c[1]), ...rows.map(r => COLS.map(c => c[0] === 'comp' ? r.comp + '%' : r[c[0]]))]))
  return <div className="space-y-4">
    <PageHead title="Case Records"><Btn v="ghost" onClick={exp} disabled={!rows.length}><Download size={16} />Export CSV</Btn><Link to="/app/new" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-bg">New case</Link></PageHead>
    <Alert>Local demonstration storage (this browser only). Not a secure case-management system – do not store real sensitive information.</Alert>
    <div className="flex flex-wrap gap-3"><input aria-label="Search by case ID" placeholder="Search by case ID" value={q} onChange={e => { setQ(e.target.value); setPg(0) }} className="rounded-lg border border-line bg-card px-3 py-2 text-sm" />
      <select aria-label="Filter by status" value={st} onChange={e => { setSt(e.target.value); setPg(0) }} className="rounded-lg border border-line bg-card px-3 py-2 text-sm">{['All', 'Draft', 'Submitted', 'Analysed'].map(s => <option key={s}>{s}</option>)}</select></div>
    <Card>{!rows.length ? <Empty title="No cases found" text="Change the search or filter, or create a new case." /> :
      <><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-muted"><tr>{COLS.map(([k, l]) => <th key={k} className="border-b border-line px-3 py-2"><button onClick={() => sort(k)} className="whitespace-nowrap font-medium hover:text-ink">{l}{key === k ? (dir > 0 ? ' ▲' : ' ▼') : ''}</button></th>)}<th className="border-b border-line px-3 py-2 font-medium">Actions</th></tr></thead>
        <tbody>{page.map(r => <tr key={r.id}><Td>{r.id}</Td><Td>{r.title}</Td><Td>{r.discDate}</Td><Td>{r.discTime}</Td><Td>{r.comp}%</Td><Td><Badge tone={statusTone(r.status)}>{r.status}</Badge></Td><Td>{r.created}</Td>
          <Td><div className="flex gap-2"><button aria-label="View case" onClick={() => setView(r)}><Eye size={16} /></button>{r.status === 'Draft' && <Link aria-label="Edit draft" to={`/app/new?edit=${r.id}`}><Pencil size={16} /></Link>}<button aria-label="Delete case" onClick={() => setDel(r)}><Trash2 size={16} className="text-red-300" /></button></div></Td></tr>)}</tbody></table></div>
        <div className="mt-3 flex items-center justify-end gap-3 text-sm text-muted"><button aria-label="Previous page" disabled={cur === 0} onClick={() => setPg(cur - 1)}><ChevronLeft /></button>Page {cur + 1} of {pages}<button aria-label="Next page" disabled={cur >= pages - 1} onClick={() => setPg(cur + 1)}><ChevronRight /></button></div></>}</Card>
    {view && <Modal title={view.id} onClose={() => setView(null)} footer={view.status !== 'Draft' && <Link className="text-sm text-primary" to={`/app/results/${view.id}`}>Open analysis results</Link>}><dl className="space-y-1 text-sm">{summaryRows(view).map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="text-muted">{k}</dt><dd className="text-right">{v}</dd></div>)}</dl></Modal>}
    {del && <Confirm danger title="Delete this case?" text={`${del.id} will be removed from local storage. This cannot be undone.`} yes="Delete" onYes={() => { deleteCase(del.id); setDel(null) }} onNo={() => setDel(null)} />}
  </div>
}
