import { Link } from 'react-router-dom'
import { Fingerprint, FolderOpen, Database, BarChart3, FlaskConical, ArrowRight } from 'lucide-react'
import { Card } from '../components/ui'
export const DISCLAIMER = 'This application is an educational prototype. It does not replace professional forensic examination and must not be used as the sole basis for real investigations.'
const F = [[FolderOpen, 'Case Information Management', 'Structured forms that keep unknown values distinct from zero.'], [Database, 'Historical Data Analysis', 'Upload CSV data and review its quality in the browser.'], [BarChart3, 'Interactive Data Visualization', 'Filterable charts with clear sample-data labels.'], [FlaskConical, 'Experimental Model Evaluation', 'Metrics appear only after a real evaluation is run.']]
export const FLOW = ['Data Collection', 'Data Cleaning', 'Data Storage', 'Data Analysis', 'Visualization', 'Model Evaluation', 'Report Generation']
export default function Landing() {
  return <div className="min-h-screen bg-gradient-to-b from-bg to-side">
    <header className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-4">
      <Link to="/" className="flex items-center gap-2 font-semibold"><Fingerprint className="text-primary" />Forensic TOD</Link>
      <nav className="ml-auto hidden items-center gap-5 text-sm text-muted sm:flex"><a href="#home" className="hover:text-ink">Home</a><a href="#features" className="hover:text-ink">Features</a><a href="#about" className="hover:text-ink">About</a><Link to="/app" className="hover:text-ink">Dashboard</Link></nav>
      <Link to="/app/new" className="ml-auto rounded-lg bg-primary px-4 py-2 text-sm font-medium text-bg sm:ml-0">Get Started</Link></header>
    <section id="home" className="mx-auto max-w-4xl px-4 py-20 text-center">
      <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Forensic Time-of-Death Estimation</h1>
      <p className="mt-3 text-xl text-primary">A Data-Driven Forensic Analytics Platform</p>
      <p className="mx-auto mt-4 max-w-2xl text-muted">Explore historical forensic research data, environmental observations, and analytical patterns to support preliminary investigation and research.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3"><Link to="/app/new" className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 font-medium text-bg">Start New Case <ArrowRight size={16} /></Link><Link to="/app" className="rounded-lg border border-line px-5 py-2.5 hover:bg-line/50">Explore Dashboard</Link></div></section>
    <section id="features" className="mx-auto grid max-w-6xl gap-4 px-4 sm:grid-cols-2 lg:grid-cols-4">{F.map(([I, t, d]) => <Card key={t}><I className="mb-3 text-primary" /><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-muted">{d}</p></Card>)}</section>
    <section className="mx-auto max-w-6xl px-4 py-16"><h2 className="mb-5 text-xl font-semibold">Analytical workflow</h2>
      <ol className="flex flex-wrap items-center gap-2 text-sm">{FLOW.map((s, i) => <li key={s} className="flex items-center gap-2"><span className="rounded-lg border border-line bg-card px-3 py-1.5">{s}</span>{i < FLOW.length - 1 && <ArrowRight size={14} className="text-muted" />}</li>)}</ol></section>
    <section id="about" className="mx-auto max-w-6xl px-4 pb-16"><Card><h2 className="mb-2 text-xl font-semibold">Role of Big Data Analytics</h2><p className="text-sm text-muted">Forensic research produces large, varied and often incomplete records. Big data techniques – cleaning, storage, exploratory analysis, visualization and rigorous model evaluation – make those records accessible and reveal where data is too weak to support any conclusion. This prototype demonstrates that pipeline on sample data.</p></Card></section>
    <footer className="border-t border-line px-4 py-8 text-center text-sm text-muted"><p className="font-medium text-ink">Forensic Time-of-Death Estimation – Big Data Analytics project</p><p className="mx-auto mt-2 max-w-2xl text-warning">{DISCLAIMER}</p></footer></div>
}
