import { useState } from 'react'
import { Upload, Download } from 'lucide-react'
import { Card, Alert, Spinner, Btn, Badge, Table, Td, Empty, PageHead } from '../components/ui'
import { parseCSV, analyze, toCSV, download } from '../utils/csv'
import { useApi } from '../hooks/useApi'
import { api } from '../utils/api'
const f2 = v => Number.isInteger(v) ? v : v.toFixed(2)
function ServerDataset() {
  const res = useApi(o => api.summary(o), []), d = res.data?.data
  return <Card><h3 className="mb-1 font-medium">Dataset loaded by the backend</h3>
    {res.loading && <Spinner text="Contacting backend…" />}
    {res.error && <Alert tone="err">{res.error.message}</Alert>}
    {d && <div className="space-y-3 text-sm">
      <p className="text-muted">{d.file_name} · {d.rows.toLocaleString()} rows · {d.columns} columns · dates {d.date_range.min} to {d.date_range.max} (filtered on {d.date_basis}). {d.is_synthetic && <Badge tone="warn">Synthetic educational data</Badge>}</p>
      {d.validation.warnings.length ? <Alert>{d.validation.warnings.map(w => <p key={w}>• {w}</p>)}</Alert> : <Alert tone="ok">Backend validation found no warnings.</Alert>}
      <p className="text-muted">{d.target_note}</p>
      <details><summary className="cursor-pointer text-primary">Column mapping and quality ({d.columns_info.length} columns)</summary>
        <Table head={['Application field', 'CSV column', 'Type', 'Blank', 'Not applicable']}>{Object.entries(d.column_mapping).map(([k, c]) => { const i = d.columns_info.find(x => x.name === c) || {}; return <tr key={k}><Td>{k}</Td><Td>{c}</Td><Td><Badge tone="info">{i.type}</Badge></Td><Td>{i.missing}</Td><Td>{i.not_applicable}</Td></tr> })}</Table>
        {d.missing_optional_fields.length > 0 && <p className="mt-2 text-warning">Not present in the file: {d.missing_optional_fields.join(', ')}</p>}</details></div>}
  </Card>
}
export default function Explorer() {
  const [name, setName] = useState(''), [res, setRes] = useState(null), [err, setErr] = useState(''), [busy, setBusy] = useState(false)
  const pick = e => {
    const file = e.target.files?.[0]; e.target.value = ''
    if (!file) return
    setErr(''); setRes(null); setName(file.name)
    if (!/\.csv$/i.test(file.name)) return setErr('Unsupported file type. Choose a .csv file.')
    if (file.size === 0) return setErr('The file is empty.')
    if (file.size > 5 * 1024 * 1024) return setErr('The file is larger than 5 MB. Use a smaller sample.')
    setBusy(true)
    const r = new FileReader()
    r.onerror = () => { setBusy(false); setErr('The file could not be read.') }
    r.onload = () => { try { setRes(analyze(parseCSV(String(r.result).replace(/^\uFEFF/, '')))) } catch (x) { setErr('Could not process the file: ' + x.message) } setBusy(false) }
    r.readAsText(file)
  }
  const num = res?.cols.filter(c => c.stats) || []
  return <div className="space-y-4">
    <PageHead title="Data Explorer" />
    <ServerDataset />
    <Alert>Files you choose below are processed in your browser and never uploaded. The backend dataset above is configured on the server (DATASET_PATH). These are basic checks only – validating forensic datasets also needs domain-specific review.</Alert>
    <Card><label className="inline-flex cursor-pointer items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-bg focus-within:outline focus-within:outline-2"><Upload size={16} />Choose CSV file<input type="file" accept=".csv,text/csv" className="sr-only" onChange={pick} /></label>
      {name && <span className="ml-3 text-sm text-muted">Selected: {name}</span>}</Card>
    {busy && <Spinner text="Reading and checking file…" />}
    {err && <Alert tone="err">{err}</Alert>}
    {!res && !busy && !err && <Card><Empty title="No dataset loaded" text="Choose a CSV file to preview it and see missing values, duplicates, data types and statistics." /></Card>}
    {res && <>
      <div className="grid gap-4 sm:grid-cols-4">{[['Rows', res.body.length], ['Columns', res.header.length], ['Missing cells', res.cols.reduce((a, c) => a + c.missing, 0)], ['Duplicate rows', res.dupes]].map(([l, v]) => <Card key={l}><p className="text-sm text-muted">{l}</p><p className="text-2xl font-semibold">{v}</p></Card>)}</div>
      {res.warnings.length ? <Alert>{res.warnings.map(w => <p key={w}>• {w}</p>)}</Alert> : <Alert tone="ok">No basic quality warnings found.</Alert>}
      <div className="flex flex-wrap gap-2"><Btn v="ghost" onClick={() => download('data-quality-summary.csv', toCSV([['Column', 'Type', 'Missing', 'Min', 'Mean', 'Max'], ...res.cols.map(c => [c.name, c.type, c.missing, c.stats?.min ?? '', c.stats ? f2(c.stats.mean) : '', c.stats?.max ?? '']), [], ['Duplicate rows', res.dupes]]))}><Download size={16} />Export quality summary</Btn>
        <Btn v="ghost" onClick={() => download('processed-' + name, toCSV([res.header, ...res.unique]))}><Download size={16} />Download processed CSV (duplicates removed)</Btn></div>
      <Card><h3 className="mb-2 font-medium">Columns</h3><Table head={['Column', 'Inferred type', 'Missing']}>{res.cols.map(c => <tr key={c.name}><Td>{c.name || '(blank)'}</Td><Td><Badge tone="info">{c.type}</Badge></Td><Td>{c.missing}</Td></tr>)}</Table></Card>
      {num.length > 0 && <Card><h3 className="mb-2 font-medium">Descriptive statistics</h3><Table head={['Column', 'Min', 'Max', 'Mean', 'Median', 'Std dev']}>{num.map(c => <tr key={c.name}><Td>{c.name}</Td>{['min', 'max', 'mean', 'median', 'std'].map(k => <Td key={k}>{f2(c.stats[k])}</Td>)}</tr>)}</Table></Card>}
      <Card><h3 className="mb-2 font-medium">Preview (first 10 rows)</h3><Table head={res.header.map((h, i) => h || 'col' + (i + 1))}>{res.body.slice(0, 10).map((r, i) => <tr key={i}>{res.header.map((_, j) => <Td key={j}>{r[j]}</Td>)}</tr>)}</Table></Card></>}
  </div>
}
