import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ResponsiveContainer, LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, Legend, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts'
import { Card, Sample, Badge, statusTone, Btn, Table, Td, Modal, tip, COLORS } from '../components/ui'
import { ROWS, agg, ACTIVITY, DATASETS } from '../data/sample'
import { useCases } from '../utils/store'
import { useApi } from '../hooks/useApi'
import { api } from '../utils/api'
const ax = { stroke: '#94A3B8', fontSize: 12 }
export const Chart = ({ title, children, live }) => <Card><div className="mb-3 flex items-center justify-between"><h3 className="font-medium">{title}</h3>{live ? <Badge tone="info">Live data</Badge> : <Sample />}</div><div className="h-64"><ResponsiveContainer>{children}</ResponsiveContainer></div></Card>
const toNV = (rows, k = 'label') => (rows || []).map(r => ({ name: r[k], value: r.count }))
export default function Overview() {
  const cases = useCases(), [sel, setSel] = useState(null), d = DATASETS[0]
  const res = useApi(async o => { const [summary, years, temp, scene, quality] = await Promise.all([api.summary(o), api.byYear({}, o), api.temperature({}, o), api.byScene({}, o), api.quality({}, o)]); return { summary: summary.data, years: years.data, temp: temp.data, scene: scene.data, quality: quality.data } }, [])
  const L = res.data, live = !!L
  const complete = L?.quality.status_counts.find(s => s.key === 'validated_complete')?.count ?? 0
  const blank = L ? L.summary.columns_info.reduce((a, c) => a + c.missing, 0) : 0
  const cards = live
    ? [['Total Dataset Records', L.summary.rows.toLocaleString(), true], ['Fully Complete Records', complete.toLocaleString(), true], ['Blank Cells', blank.toLocaleString(), true], ['Cases Analysed (local)', cases.filter(c => c.status === 'Analysed' && !c.demo).length, false]]
    : [['Total Dataset Records', d.records.toLocaleString()], ['Valid Records', d.valid.toLocaleString()], ['Missing Values', d.missing.toLocaleString()], ['Analysis Sessions', 14 + cases.filter(c => c.status === 'Analysed' && !c.demo).length]]
  const years = live ? toNV(L.years) : agg(ROWS, 'year'), bins = live ? toNV(L.temp.bins) : agg(ROWS, 'bin'), cats = live ? toNV(L.scene) : agg(ROWS, 'cat')
  const pie = live ? L.quality.status_counts.map(s => ({ name: s.label, value: s.count })) : [{ name: 'Valid', value: d.valid }, { name: 'Missing', value: d.missing }, { name: 'Duplicate', value: d.dupes }]
  const grid = <CartesianGrid stroke="#263449" strokeDasharray="3 3" />
  return <div className="space-y-5">
    {live ? <div className="rounded-xl border border-secondary/40 bg-secondary/10 px-4 py-2 text-sm text-secondary">Dataset figures and charts are loaded live from the backend ({L.summary.file_name}{L.summary.is_synthetic ? ' – synthetic educational data' : ''}). The recent-activity table below is still sample data.</div>
      : <div className="rounded-xl border border-warning/40 bg-warning/10 px-4 py-2 text-sm text-warning">{res.loading ? 'Connecting to the backend… showing sample demonstration data meanwhile.' : `${res.error?.message || 'Backend unavailable.'} Showing sample demonstration data, not a real connected dataset.`}</div>}
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map(([l, v, isLive]) => <Card key={l}><p className="text-sm text-muted">{l}</p><p className="mt-1 text-2xl font-semibold">{v}</p>{live ? (isLive ? <Badge tone="info">Live data</Badge> : <Badge>Local browser storage</Badge>) : <Sample />}</Card>)}</div>
    <div className="grid gap-4 lg:grid-cols-2">
      <Chart live={live} title="Historical Records Over Time"><LineChart data={years}>{grid}<XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Line dataKey="value" name="Records" stroke="#38BDF8" strokeWidth={2} /></LineChart></Chart>
      <Chart live={live} title="Environmental Temperature Distribution"><AreaChart data={bins}>{grid}<XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Area dataKey="value" name="Records" stroke="#34D399" fill="#34D39933" /></AreaChart></Chart>
      <Chart live={live} title={live ? 'Records by Scene Type' : 'Observation Categories'}><BarChart data={cats}>{grid}<XAxis dataKey="name" {...ax} /><YAxis {...ax} /><Tooltip {...tip} /><Bar dataKey="value" name="Records" fill="#38BDF8" radius={[6, 6, 0, 0]} /></BarChart></Chart>
      <Chart live={live} title="Dataset Quality Distribution"><PieChart><Pie data={pie} dataKey="value" innerRadius={55} outerRadius={85}>{pie.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip {...tip} /><Legend /></PieChart></Chart>
    </div>
    <Card><div className="mb-3 flex items-center justify-between"><h3 className="font-medium">Recent activity</h3><Sample /></div>
      <Table head={['Case ID', 'Dataset', 'Analysis Date', 'Records Analysed', 'Status', 'Action']}>{ACTIVITY.map(a => <tr key={a.caseId}><Td>{a.caseId}</Td><Td>{a.dataset}</Td><Td>{a.date}</Td><Td>{a.records.toLocaleString()}</Td><Td><Badge tone={statusTone(a.status)}>{a.status}</Badge></Td><Td><Btn v="ghost" className="!py-1" onClick={() => setSel(a)}>View Details</Btn></Td></tr>)}</Table></Card>
    {sel && <Modal title={sel.caseId} onClose={() => setSel(null)} footer={<Link className="text-sm text-primary" to="/app/records">Open case records</Link>}><Sample>Sample activity record</Sample><dl className="mt-3 space-y-1 text-sm">{Object.entries(sel).map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="text-muted">{k}</dt><dd>{String(v)}</dd></div>)}</dl></Modal>}
  </div>
}
