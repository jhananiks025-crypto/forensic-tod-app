import { useState, useMemo } from 'react'
import { BarChart, Bar, Cell, PieChart, Pie, Legend, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts'
import { ChevronRight, ArrowLeft, XCircle, RefreshCw } from 'lucide-react'
import { Card, PageHead, Alert, Btn, Spinner, Badge, tip, COLORS } from '../components/ui'
import { LiveChart, Stat, Chip, pretty, fmt } from '../components/analytics/parts'
import RecordsPanel from '../components/analytics/RecordsPanel'
import { useApi } from '../hooks/useApi'
import { api } from '../utils/api'

const sel = 'rounded-lg border border-line bg-card px-3 py-2 text-sm'
const ax = { stroke: '#94A3B8', fontSize: 12 }
const grid = <CartesianGrid stroke="#263449" strokeDasharray="3 3" />
const BLUE = '#38BDF8', AMBER = '#FBBF24', GREEN = '#34D399', GREY = '#475569'
const EMPTY = { from: '', to: '', scene: '', location: '' }
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
const clickedPayload = d => d?.payload ?? d

export default function Analytics() {
  const [draft, setDraft] = useState(EMPTY), [applied, setApplied] = useState(EMPTY)
  const [drill, setDrill] = useState({ year: null, month: null }), [picks, setPicks] = useState({})
  const summary = useApi(o => api.summary(o), [])

  const params = useMemo(() => ({
    date_from: applied.from, date_to: applied.to, scene_type: applied.scene, location_category: applied.location,
    year: drill.year, month: drill.month, temp_min: picks.temp?.min, temp_max: picks.temp?.max,
    pmi_min: picks.pmi?.min, pmi_max: picks.pmi?.max, data_quality_status: picks.quality,
  }), [applied, drill, picks])
  const key = JSON.stringify(params)
  const noDrill = useMemo(() => ({ ...params, year: undefined, month: undefined }), [params])
  const noDrillKey = JSON.stringify(noDrill)
  const ready = !!summary.data

  const overview = useApi(o => api.overview(params, o), [key], ready)
  const main = useApi(o => api.drilldown({ ...params, level: drill.year ? 'month' : 'year' }, o), [key, drill.year], ready)
  const timeline = useApi(o => api.byMonth(noDrill, o), [noDrillKey], ready)
  const scene = useApi(o => api.byScene(params, o), [key], ready)
  const location = useApi(o => api.byLocation(params, o), [key], ready)
  const temp = useApi(o => api.temperature(params, o), [key], ready)
  const pmi = useApi(o => api.pmi(params, o), [key], ready)
  const quality = useApi(o => api.quality(params, o), [key], ready)

  if (summary.error) return <div className="space-y-4"><PageHead title="Analytics & Charts" />
    <Card><Alert tone="err">{summary.error.message}</Alert>
      <p className="mt-3 text-sm text-muted">This page reads all its figures from the Python backend and shows no placeholder values when it is unavailable.</p>
      <Btn className="mt-3" onClick={summary.reload}><RefreshCw size={16} />Try again</Btn></Card></div>
  if (!summary.data) return <div className="space-y-4"><PageHead title="Analytics & Charts" /><Card><Spinner text="Connecting to the analytics backend…" /></Card></div>

  const info = summary.data.data, range = info.date_range, opts = info.filter_options || {}
  const draftErr = draft.from && draft.to && draft.from > draft.to ? 'The start date cannot be after the end date.' : ''
  const ov = overview.data?.data, meta = overview.data?.meta
  const dirty = JSON.stringify(draft) !== JSON.stringify(applied)
  const setDrillTo = d => setDrill(d)
  const toggleFilter = (k, v) => { const nv = applied[k] === v ? '' : v; setApplied(a => ({ ...a, [k]: nv })); setDraft(a => ({ ...a, [k]: nv })) }
  const togglePick = (k, v) => setPicks(p => ({ ...p, [k]: JSON.stringify(p[k]) === JSON.stringify(v) ? undefined : v }))
  const reset = () => { setDraft(EMPTY); setApplied(EMPTY); setDrill({ year: null, month: null }); setPicks({}) }
  const back = () => setDrill(d => d.month ? { year: d.year, month: null } : { year: null, month: null })
  const rangeNote = applied.from && range.max && applied.from > range.max || applied.to && range.min && applied.to < range.min
    ? `The selected range lies outside the dataset (${range.min} to ${range.max}); no records can match.`
    : (applied.from && range.min && applied.from < range.min) || (applied.to && range.max && applied.to > range.max)
      ? `The dataset only covers ${range.min} to ${range.max}; the range is effectively clipped to that period.` : ''
  const anyActive = applied.from || applied.to || applied.scene || applied.location || drill.year || Object.values(picks).some(Boolean)
  const periodText = applied.from || applied.to ? `${applied.from || range.min} to ${applied.to || range.max} (inclusive)` : `${range.min} to ${range.max} (full dataset)`

  const mainBuckets = main.data?.data?.buckets || []
  const pmiData = pmi.data?.data, tempData = temp.data?.data
  const mainTitle = drill.year ? `Cases by month – ${drill.year}` : 'Cases by year'

  return <div className="space-y-4">
    <PageHead title="Analytics & Charts" />
    {info.is_synthetic && <Alert>{info.data_notice} Charts are descriptive only and do not establish any scientific relationship; they are not predictions.</Alert>}
    {info.validation.warnings.length > 0 && <Alert>{info.validation.warnings.map(w => <p key={w}>• {w}</p>)}</Alert>}

    <Card>
      <form className="flex flex-wrap items-end gap-4 text-sm" onSubmit={e => { e.preventDefault(); if (!draftErr) setApplied({ ...draft }) }}>
        <label>Start date<input type="date" className={sel + ' mt-1 block'} value={draft.from} onChange={e => setDraft({ ...draft, from: e.target.value })} aria-invalid={!!draftErr} /></label>
        <label>End date<input type="date" className={sel + ' mt-1 block'} value={draft.to} onChange={e => setDraft({ ...draft, to: e.target.value })} aria-invalid={!!draftErr} /></label>
        <label>Scene type<select className={sel + ' mt-1 block'} value={draft.scene} onChange={e => setDraft({ ...draft, scene: e.target.value })}><option value="">All</option>{(opts.scene_type || []).map(v => <option key={v} value={v}>{pretty(v)}</option>)}</select></label>
        <label>Location category<select className={sel + ' mt-1 block'} value={draft.location} onChange={e => setDraft({ ...draft, location: e.target.value })}><option value="">All</option>{(opts.location_category || []).map(v => <option key={v} value={v}>{pretty(v)}</option>)}</select></label>
        <div className="flex gap-2"><Btn onClick={() => !draftErr && setApplied({ ...draft })} disabled={!!draftErr || !dirty}>Apply Filters</Btn><Btn v="ghost" onClick={reset} disabled={!anyActive && !dirty}>Reset Filters</Btn></div>
      </form>
      <p className="mt-2 text-xs text-muted">Dates filter on <b>discovery_datetime</b> and are interpreted as UTC calendar days; both the start and end day are included.</p>
      {draftErr && <div className="mt-2"><Alert tone="err">{draftErr}</Alert></div>}
      {rangeNote && <div className="mt-2"><Alert>{rangeNote}</Alert></div>}
    </Card>

    <div className="flex flex-wrap items-center gap-2 text-sm" aria-live="polite">
      <span className="text-muted">Period: <b className="text-ink">{periodText}</b></span><span className="text-muted">·</span>
      <span className="text-muted">Matching records: <b className="text-ink">{overview.error ? '—' : meta ? `${meta.filtered_count.toLocaleString()} of ${meta.dataset_total.toLocaleString()}` : '…'}</b></span>
      {applied.scene && <Chip onClear={() => toggleFilter('scene', applied.scene)}>Scene: {pretty(applied.scene)}</Chip>}
      {applied.location && <Chip onClear={() => toggleFilter('location', applied.location)}>Location: {pretty(applied.location)}</Chip>}
      {picks.temp && <Chip onClear={() => togglePick('temp', picks.temp)}>Temperature {picks.temp.label} °C</Chip>}
      {picks.pmi && <Chip onClear={() => togglePick('pmi', picks.pmi)}>PMI label {picks.pmi.label}</Chip>}
      {picks.quality && <Chip onClear={() => togglePick('quality', picks.quality)}>Quality: {pretty(picks.quality)}</Chip>}
    </div>

    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Stat label="Cases in view" res={overview} value={ov ? ov.total_records.toLocaleString() : ''} sub={meta ? `of ${meta.dataset_total.toLocaleString()} in dataset` : ''} />
      <Stat label="Mean ambient temperature" res={overview} value={ov?.ambient_temperature_c ? `${fmt(ov.ambient_temperature_c.mean)} °C` : '—'} sub={ov?.ambient_temperature_c ? `range ${fmt(ov.ambient_temperature_c.min)} to ${fmt(ov.ambient_temperature_c.max)} °C` : 'no temperature values'} />
      <Stat label="Median PMI (reference label)" res={overview} value={ov?.pmi_hours ? `${fmt(ov.pmi_hours.median)} h` : '—'} sub={ov && !ov.pmi_available ? 'No valid PMI labels in dataset' : 'dataset label, not a prediction'} />
      <Stat label="Fully complete records" res={overview} value={ov?.complete_pct != null ? `${ov.complete_pct}%` : '—'} sub={ov?.complete_records != null ? `${ov.complete_records.toLocaleString()} records` : ''} />
    </div>

    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <nav aria-label="Drill-down breadcrumb" className="flex flex-wrap items-center gap-1 text-sm">
          <button className={drill.year ? 'text-primary hover:underline' : 'font-medium'} onClick={() => setDrillTo({ year: null, month: null })}>All Years</button>
          {drill.year && <><ChevronRight size={14} className="text-muted" /><button className={drill.month ? 'text-primary hover:underline' : 'font-medium'} onClick={() => setDrillTo({ year: drill.year, month: null })}>{drill.year}</button></>}
          {drill.month && <><ChevronRight size={14} className="text-muted" /><span className="font-medium">{MONTHS[drill.month - 1]}</span></>}
        </nav>
        <div className="flex gap-2"><Btn v="ghost" className="!py-1" onClick={back} disabled={!drill.year}><ArrowLeft size={14} />Back</Btn>
          <Btn v="ghost" className="!py-1" onClick={() => setDrillTo({ year: null, month: null })} disabled={!drill.year}><XCircle size={14} />Clear drill-down</Btn></div></div>
      <LiveChart title={mainTitle} res={main} note={drill.year ? 'Click a month to list its cases below.' : 'Click a year to see its months.'} isEmpty={main.data?.data?.empty}
        emptyText={drill.year ? `No cases in ${drill.year} match the current filters. Use Back or choose another year.` : 'No cases match the current filters.'}>
        <ResponsiveContainer><BarChart data={mainBuckets}>{grid}<XAxis dataKey="label" {...ax} /><YAxis allowDecimals={false} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
          <Bar dataKey="count" name="Cases" radius={[6, 6, 0, 0]} cursor="pointer" onClick={d => { const b = clickedPayload(d); setDrillTo(drill.year ? { year: drill.year, month: b.month } : { year: b.year, month: null }) }}>
            {mainBuckets.map(b => <Cell key={b.key} fill={drill.month && b.month === drill.month ? AMBER : BLUE} />)}</Bar></BarChart></ResponsiveContainer>
      </LiveChart>
    </Card>

    <LiveChart title="Monthly timeline (all years)" res={timeline} note="Respects the date range and filters but not the year/month drill-down. Click a bar to jump straight to that month." isEmpty={timeline.data && timeline.data.meta.filtered_count === 0}>
      <ResponsiveContainer><BarChart data={timeline.data?.data || []}>{grid}<XAxis dataKey="label" interval={5} {...ax} /><YAxis allowDecimals={false} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
        <Bar dataKey="count" name="Cases" fill={GREEN} radius={[3, 3, 0, 0]} cursor="pointer" onClick={d => { const b = clickedPayload(d); setDrillTo({ year: b.year, month: b.month }) }}>
          {(timeline.data?.data || []).map(b => <Cell key={b.key} fill={drill.year === b.year && drill.month === b.month ? AMBER : GREEN} />)}</Bar></BarChart></ResponsiveContainer>
    </LiveChart>

    <div className="grid gap-4 lg:grid-cols-2">
      <LiveChart title="Cases by scene type" res={scene} note="Click a bar to filter by scene type." isEmpty={!scene.data?.data?.length}>
        <ResponsiveContainer><BarChart data={scene.data?.data || []}>{grid}<XAxis dataKey="label" {...ax} /><YAxis allowDecimals={false} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
          <Bar dataKey="count" name="Cases" radius={[6, 6, 0, 0]} cursor="pointer" onClick={d => toggleFilter('scene', clickedPayload(d).key)}>
            {(scene.data?.data || []).map(b => <Cell key={b.key} fill={applied.scene === b.key ? AMBER : BLUE} />)}</Bar></BarChart></ResponsiveContainer>
      </LiveChart>
      <LiveChart title="Available records by location category" res={location} note="Click a bar to filter by location." isEmpty={!location.data?.data?.length}>
        <ResponsiveContainer><BarChart data={location.data?.data || []} layout="vertical" margin={{ left: 20 }}>{grid}<XAxis type="number" allowDecimals={false} {...ax} /><YAxis type="category" dataKey="label" width={150} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
          <Bar dataKey="count" name="Cases" radius={[0, 6, 6, 0]} cursor="pointer" onClick={d => toggleFilter('location', clickedPayload(d).key)}>
            {(location.data?.data || []).map(b => <Cell key={b.key} fill={applied.location === b.key ? AMBER : BLUE} />)}</Bar></BarChart></ResponsiveContainer>
      </LiveChart>
      <LiveChart title="Ambient temperature distribution (°C)" res={temp} unavailable={tempData && !tempData.available ? tempData.reason : ''} isEmpty={tempData?.available && tempData.n_with_value === 0}
        note={tempData?.available ? `${tempData.n_with_value.toLocaleString()} records with a temperature value; bins are ${tempData.bin_width} °C wide (lower bound included). Click a bar to list those records.` : ''}>
        <ResponsiveContainer><BarChart data={tempData?.bins || []}>{grid}<XAxis dataKey="label" {...ax} /><YAxis allowDecimals={false} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
          <Bar dataKey="count" name="Cases" radius={[6, 6, 0, 0]} cursor="pointer" onClick={d => { const b = clickedPayload(d); togglePick('temp', { min: b.min, max: b.max, label: b.label }) }}>
            {(tempData?.bins || []).map(b => <Cell key={b.label} fill={picks.temp?.min === b.min ? AMBER : GREEN} />)}</Bar></BarChart></ResponsiveContainer>
      </LiveChart>
      <LiveChart title="Postmortem interval distribution (hours)" res={pmi} unavailable={pmiData && !pmiData.available ? pmiData.reason : ''} isEmpty={pmiData?.available && pmiData.n_with_value === 0}
        note={pmiData?.available ? pmiData.note : ''}>
        <ResponsiveContainer><BarChart data={pmiData?.bins || []}>{grid}<XAxis dataKey="label" {...ax} /><YAxis allowDecimals={false} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} />
          <Bar dataKey="count" name="Cases" radius={[6, 6, 0, 0]} cursor="pointer" onClick={d => { const b = clickedPayload(d); togglePick('pmi', { min: b.min, max: b.max ?? undefined, label: b.label }) }}>
            {(pmiData?.bins || []).map(b => <Cell key={b.label} fill={picks.pmi?.min === b.min ? AMBER : BLUE} />)}</Bar></BarChart></ResponsiveContainer>
      </LiveChart>
      <LiveChart title="Data quality status" res={quality} note="Click a slice to list those records." isEmpty={!quality.data?.data?.status_counts?.length}>
        <ResponsiveContainer><PieChart><Pie data={quality.data?.data?.status_counts || []} dataKey="count" nameKey="label" innerRadius={55} outerRadius={85} cursor="pointer" onClick={d => togglePick('quality', clickedPayload(d).key)}>
          {(quality.data?.data?.status_counts || []).map((s, i) => <Cell key={s.key} fill={picks.quality === s.key ? AMBER : COLORS[i % COLORS.length]} />)}</Pie><Tooltip {...tip} /><Legend /></PieChart></ResponsiveContainer>
      </LiveChart>
      <LiveChart title="Field completeness" res={quality} note={quality.data?.data?.note} isEmpty={!quality.data?.data?.fields?.length}>
        <ResponsiveContainer><BarChart data={quality.data?.data?.fields || []} layout="vertical" margin={{ left: 20 }}>{grid}<XAxis type="number" allowDecimals={false} {...ax} /><YAxis type="category" dataKey="label" width={150} {...ax} /><Tooltip {...tip} cursor={{ fill: '#ffffff10' }} /><Legend />
          <Bar dataKey="available" name="Available" stackId="a" fill={GREEN} /><Bar dataKey="not_applicable" name="Not applicable" stackId="a" fill={GREY} /><Bar dataKey="missing" name="Missing" stackId="a" fill={AMBER} /></BarChart></ResponsiveContainer>
      </LiveChart>
    </div>

    <RecordsPanel params={params} heading={drill.month ? `Cases – ${MONTHS[drill.month - 1]} ${drill.year}` : drill.year ? `Cases – ${drill.year}` : 'Case records for current view'} />
  </div>
}
