import { Link, useParams } from 'react-router-dom'
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts'
import { Card, Badge, Bar as Prog, Btn, Empty, Sample, PageHead, Table, Td, statusTone, tip } from '../components/ui'
import { useCases, completeness, summaryRows } from '../utils/store'
import { requiredInputs, MSG_UNAVAILABLE, MSG_DONE, MODEL_CONNECTED } from '../utils/analysis'
import { ROWS, agg, DATASETS } from '../data/sample'
import { toCSV, download } from '../utils/csv'
export default function Results() {
  const { id } = useParams(), c = useCases().find(x => x.id === id)
  if (!c) return <Card><Empty title="Case not found" text="This case may have been deleted from local storage."><Link className="text-primary" to="/app/records">Go to case records</Link></Empty></Card>
  const comp = completeness(c), req = requiredInputs(c)
  const ev = [['Last known alive', c.lastAliveDate, c.lastAliveTime], ['Discovery', c.discDate, c.discTime], ['Incident reported', c.reportedDate, c.reportedTime]]
  return <div className="space-y-5">
    <PageHead title={`Analysis results – ${c.id}`}><Btn v="ghost" onClick={() => download(`${c.id}-summary.csv`, toCSV([['Field', 'Value'], ...summaryRows(c), ['Note', 'Educational prototype - not an official forensic report']]))}>Download Case Summary</Btn><Link to="/app" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-bg">Return to Dashboard</Link></PageHead>
    <div className="rounded-xl border border-warning/40 bg-warning/10 p-3 text-sm text-warning"><b>DEMONSTRATION RESULT.</b> {MSG_DONE}</div>
    <div className="grid gap-4 lg:grid-cols-3">
      <Card><h3 className="mb-2 font-medium">Case summary</h3><p className="text-sm">{c.title}</p><p className="text-sm text-muted">Created {c.created} · Discovered {c.discDate} {c.discTime}</p>{c.demo && <Sample>Sample case</Sample>}</Card>
      <Card><h3 className="mb-2 font-medium">Data completeness</h3><p className="mb-1 text-2xl font-semibold">{comp}%</p><Prog value={comp} /><p className="mt-2 text-xs text-muted">Share of key fields provided. Unknown values are not counted as zero.</p></Card>
      <Card><h3 className="mb-2 font-medium">Analysis status</h3><Badge tone={statusTone(c.status)}>{c.status}</Badge><p className="mt-2 text-sm text-muted">Dataset: {DATASETS[0].name}</p>{c.analysis && <p className="text-xs text-muted">Run at {new Date(c.analysis.at).toLocaleString()}</p>}</Card></div>
    <Card><h3 className="mb-3 font-medium">Estimation status</h3>
      {MODEL_CONNECTED ? null : <div className="rounded-lg border border-line p-4"><p className="font-medium">{MSG_UNAVAILABLE}</p><p className="mt-1 text-xs text-muted">SAMPLE OUTPUT — NOT A REAL FORENSIC ESTIMATE: this prototype shows no estimated interval.</p></div>}</Card>
    <div className="grid gap-4 lg:grid-cols-2">
      <Card><h3 className="mb-3 font-medium">Timeline</h3><ol className="space-y-3 border-l border-line pl-4 text-sm">
        {ev.map(([k, d, t]) => <li key={k}><span className="font-medium">{k}</span> {d ? <Badge tone="ok">Recorded</Badge> : <Badge>Unknown</Badge>}<p className="text-muted">{d ? `${d} ${t || '(time unknown)'}` : 'Not provided'}</p></li>)}
        <li className="rounded-lg border border-dashed border-warning/60 p-2"><span className="font-medium">Time of death</span> <Badge tone="warn">Not estimated</Badge><p className="text-muted">No validated model connected. Discovery time is not time of death.</p></li></ol></Card>
      <Card><h3 className="mb-3 font-medium">Required inputs</h3><ul className="space-y-1 text-sm">{req.map(([l, ok]) => <li key={l} className="flex justify-between"><span>{l}</span><Badge tone={ok ? 'ok' : 'warn'}>{ok ? 'Available' : 'Missing'}</Badge></li>)}</ul></Card></div>
    <Card><h3 className="mb-3 font-medium">Input data summary</h3><Table head={['Field', 'Value']}>{summaryRows(c).map(([k, v]) => <tr key={k}><Td>{k}</Td><Td>{v}</Td></tr>)}</Table></Card>
    <Card><div className="mb-2 flex justify-between"><h3 className="font-medium">Historical pattern (descriptive)</h3><Sample /></div><p className="mb-2 text-xs text-muted">Record counts by environment category in sample data. No relationship to this case is implied.</p>
      <div className="h-56"><ResponsiveContainer><BarChart data={agg(ROWS, 'cat')}><CartesianGrid stroke="#263449" strokeDasharray="3 3" /><XAxis dataKey="name" stroke="#94A3B8" fontSize={12} /><YAxis stroke="#94A3B8" fontSize={12} /><Tooltip {...tip} /><Bar dataKey="value" fill="#38BDF8" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
    <div className="grid gap-4 lg:grid-cols-2">
      <Card><h3 className="mb-2 font-medium">Model validation status</h3><p className="text-sm text-muted">No validated prediction model is connected. Not evaluated.</p></Card>
      <Card><h3 className="mb-2 font-medium">Limitations and next steps</h3><ul className="list-disc space-y-1 pl-5 text-sm text-muted"><li>Sample data and demonstration logic only.</li><li>Time of death needs professional forensic examination.</li><li>Verify timeline sources and environmental readings independently.</li><li>Refer findings to a qualified forensic professional.</li></ul></Card></div>
  </div>
}
