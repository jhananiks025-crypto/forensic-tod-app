import { Routes, Route, Link } from 'react-router-dom'
import Layout from './components/Layout'
import Landing from './pages/Landing'
import Overview from './pages/Overview'
import NewCase from './pages/NewCase'
import Results from './pages/Results'
import Records from './pages/Records'
import Explorer from './pages/Explorer'
import Analysis from './pages/Analysis'
import Analytics from './pages/Analytics'
import Models from './pages/Models'
import Reports from './pages/Reports'
import About from './pages/About'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/app" element={<Layout />}>
        <Route index element={<Overview />} />
        <Route path="new" element={<NewCase />} />
        <Route path="results/:id" element={<Results />} />
        <Route path="records" element={<Records />} />
        <Route path="explorer" element={<Explorer />} />
        <Route path="analysis" element={<Analysis />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="models" element={<Models />} />
        <Route path="reports" element={<Reports />} />
        <Route path="about" element={<About />} />
      </Route>
      <Route path="*" element={<div className="p-10">Page not found. <Link className="text-primary underline" to="/">Go home</Link></div>} />
    </Routes>
  )
}
