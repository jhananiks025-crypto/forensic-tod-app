// DEMONSTRATION analysis only. It never produces a time-of-death estimate.
// FUTURE: set MODEL_CONNECTED via config and replace predictInterval with a call to a validated Python service.
import { completeness } from './store'
export const MODEL_CONNECTED = false
export const MSG_UNAVAILABLE = 'Reliable time-of-death estimation is unavailable. A validated model and further professional forensic assessment are required.'
export const MSG_DONE = 'Demonstration analysis completed. No scientifically validated death-time estimate is available in this version.'
export const requiredInputs = c => [
  ['Last-known-alive date', !!c.lastAliveDate], ['Ambient temperature observation', c.temp !== ''], ['Observation date', !!c.obsDate],
  ['Historical dataset available', c.hasDataset === 'Yes'], ['Professional examination findings', c.examStatus === 'Completed'],
]
async function predictInterval() { return { available: false } } // placeholder for a future validated model
export async function runDemoAnalysis(c) {
  await new Promise(r => setTimeout(r, 1400))
  const p = MODEL_CONNECTED ? await predictInterval(c) : { available: false }
  return { at: new Date().toISOString(), completeness: completeness(c), missing: requiredInputs(c).filter(x => !x[1]).map(x => x[0]), estimateAvailable: p.available, message: MSG_DONE }
}
