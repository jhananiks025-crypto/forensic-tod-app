// Case-management logic (local demo storage only). A real version would call a backend API instead.
import { useSyncExternalStore } from 'react'
import { SEED_CASES } from '../data/sample'
const KEY = 'fte_cases_v1'
let state = (() => { try { const v = JSON.parse(localStorage.getItem(KEY)); if (Array.isArray(v)) return v } catch {} return SEED_CASES })()
const subs = new Set()
const set = n => { state = n; try { localStorage.setItem(KEY, JSON.stringify(n)) } catch {} subs.forEach(f => f()) }
export const useCases = () => useSyncExternalStore(f => { subs.add(f); return () => subs.delete(f) }, () => state)
export const saveCase = c => set(state.some(x => x.id === c.id) ? state.map(x => x.id === c.id ? c : x) : [c, ...state])
export const deleteCase = id => set(state.filter(x => x.id !== id))
export const today = () => new Date().toISOString().slice(0, 10)
export const emptyCase = () => ({ id: 'FTE-' + Date.now().toString(36).toUpperCase().slice(-5), title: '', discDate: '', discTime: '', locCat: '', env: '', locDesc: '', lastAliveDate: '', lastAliveTime: '', reportedDate: '', reportedTime: '', tlSource: '', tlVerified: '', temp: '', unit: '°C', cond: '', tempMode: '', obsDate: '', obsTime: '', obsSource: '', hasDataset: '', hasEnv: '', hasTimeline: '', examStatus: '', notes: '' })
const dt = (d, t) => d ? new Date(`${d}T${t || '00:00'}`) : null
export function validate(c) {
  const e = {}, now = new Date()
  if (!c.id.trim()) e.id = 'Case ID is required.'
  if (!c.title.trim()) e.title = 'Enter a reference title.'
  if (!c.discDate) e.discDate = 'Date of discovery is required.'
  else if (dt(c.discDate) > now) e.discDate = 'Discovery date cannot be in the future.'
  if (!c.discTime) e.discTime = 'Time of discovery is required.'
  if (!c.locCat) e.locCat = 'Choose a location category.'
  if (!c.env) e.env = 'Choose indoor or outdoor.'
  const d = dt(c.discDate, c.discTime), a = dt(c.lastAliveDate, c.lastAliveTime), r = dt(c.reportedDate, c.reportedTime)
  if (c.lastAliveTime && !c.lastAliveDate) e.lastAliveDate = 'Add a date for this time, or clear the time.'
  else if (a && d && a > d) e.lastAliveDate = 'Last-known-alive cannot be after discovery.'
  if (c.reportedTime && !c.reportedDate) e.reportedDate = 'Add a date for this time, or clear the time.'
  else if (r && d && r < d) e.reportedDate = 'Report time cannot be before discovery.'
  if (c.temp !== '') {
    const n = Number(c.temp), f = c.unit === '°F'
    if (!Number.isFinite(n)) e.temp = 'Enter a number, or leave blank if unknown.'
    else if (n < (f ? -76 : -60) || n > (f ? 158 : 70)) e.temp = 'Value is outside a plausible range.'
    if (!c.obsDate) e.obsDate = 'Add the observation date for this reading.'
  }
  const o = dt(c.obsDate, c.obsTime)
  if (o && o > now) e.obsDate = 'Observation cannot be in the future.'
  return e
}
export const completeness = c => { const k = ['title', 'discDate', 'discTime', 'locCat', 'env', 'lastAliveDate', 'reportedDate', 'tlSource', 'tlVerified', 'temp', 'tempMode', 'obsDate', 'obsSource', 'hasDataset', 'examStatus']; return Math.round(100 * k.filter(x => String(c[x] ?? '') !== '').length / k.length) }
export const LABELS = { id: 'Case ID', title: 'Reference title', discDate: 'Discovery date', discTime: 'Discovery time', locCat: 'Location category', env: 'Environment', locDesc: 'Location description', lastAliveDate: 'Last known alive (date)', lastAliveTime: 'Last known alive (time)', reportedDate: 'Reported (date)', reportedTime: 'Reported (time)', tlSource: 'Timeline source', tlVerified: 'Timeline verified', temp: 'Ambient temperature', unit: 'Unit', cond: 'Conditions', tempMode: 'Measured or reported', obsDate: 'Observation date', obsTime: 'Observation time', obsSource: 'Measurement source', hasDataset: 'Historical dataset available', hasEnv: 'Environmental measurements available', hasTimeline: 'Timeline information available', examStatus: 'Professional forensic examination', notes: 'Notes', status: 'Analysis status' }
export const summaryRows = c => Object.entries(LABELS).map(([k, l]) => [l, String(c[k] ?? '') === '' ? 'Not provided' : c[k]])
