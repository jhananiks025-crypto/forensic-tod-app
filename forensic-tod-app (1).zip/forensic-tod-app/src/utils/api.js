// Centralised client for the Python analytics backend. All components go through this module.
const BASE = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/+$/, '')
export const API_BASE = BASE

export class ApiError extends Error {
  constructor(message, { status = 0, network = false } = {}) { super(message); this.name = 'ApiError'; this.status = status; this.network = network }
}

const qs = params => {
  const u = new URLSearchParams()
  Object.entries(params || {}).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') u.set(k, v) })
  const s = u.toString()
  return s ? '?' + s : ''
}

// FastAPI returns {detail: "text"} for our errors and {detail: [{loc, msg}, ...]} for parameter validation errors.
const detailText = d => Array.isArray(d) ? d.map(x => `${(x.loc || []).slice(1).join('.')}: ${x.msg}`).join('; ') : typeof d === 'string' ? d : ''

async function request(path, params, { signal, text } = {}) {
  let res
  try { res = await fetch(BASE + path + qs(params), { signal, headers: { Accept: text ? 'text/csv' : 'application/json' } }) }
  catch (e) {
    if (e.name === 'AbortError') throw e
    throw new ApiError(`Cannot reach the analytics backend at ${BASE}. Start it (see backend/README.md) and check VITE_API_BASE_URL.`, { network: true })
  }
  if (!res.ok) {
    let msg = ''
    try { msg = detailText((await res.json()).detail) } catch { /* non-JSON error body */ }
    throw new ApiError(msg || `The backend returned an error (HTTP ${res.status}).`, { status: res.status })
  }
  return text ? res.text() : res.json()
}

export const api = {
  health: o => request('/api/health', null, o),
  summary: o => request('/api/dataset/summary', null, o),
  overview: (p, o) => request('/api/analytics/overview', p, o),
  byYear: (p, o) => request('/api/analytics/by-year', p, o),
  byMonth: (p, o) => request('/api/analytics/by-month', p, o),
  byScene: (p, o) => request('/api/analytics/by-scene', p, o),
  byLocation: (p, o) => request('/api/analytics/by-location', p, o),
  temperature: (p, o) => request('/api/analytics/temperature-distribution', p, o),
  pmi: (p, o) => request('/api/analytics/pmi-distribution', p, o),
  quality: (p, o) => request('/api/analytics/data-quality', p, o),
  drilldown: (p, o) => request('/api/analytics/drilldown', p, o),
  cases: (p, o) => request('/api/cases', p, o),
  caseById: (id, o) => request('/api/cases/' + encodeURIComponent(id), null, o),
  exportCases: (p, o) => request('/api/cases/export', p, { ...o, text: true }),
}
