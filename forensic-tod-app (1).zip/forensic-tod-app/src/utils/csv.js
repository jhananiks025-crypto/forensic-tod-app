export function parseCSV(text) {
  const rows = []; let r = [], f = '', q = false
  for (let i = 0; i < text.length; i++) {
    const c = text[i]
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++ } else q = false } else f += c }
    else if (c === '"') q = true
    else if (c === ',') { r.push(f); f = '' }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; r.push(f); f = ''; rows.push(r); r = [] }
    else f += c
  }
  if (q) throw new Error('A quotation mark is never closed.')
  if (f !== '' || r.length) { r.push(f); rows.push(r) }
  return rows.filter(x => x.some(v => v.trim() !== ''))
}
export function analyze(all) {
  if (all.length < 2) throw new Error('The file has no data rows.')
  const header = all[0].map(h => h.trim()), body = all.slice(1), warnings = []
  if (header.some(h => !h)) warnings.push('Some column names are blank.')
  if (new Set(header).size < header.length) warnings.push('Duplicate column names found.')
  const ragged = body.filter(r => r.length !== header.length).length
  if (ragged) warnings.push(`${ragged} row(s) have a different number of fields than the header.`)
  const cols = header.map((name, i) => {
    const vals = body.map(r => (r[i] ?? '').trim()), ok = vals.filter(v => v !== '')
    const num = ok.length && ok.every(v => Number.isFinite(Number(v)))
    const date = !num && ok.length && ok.every(v => /[-/]/.test(v) && !isNaN(Date.parse(v)))
    const type = !ok.length ? 'empty' : num ? 'numeric' : date ? 'date' : 'text'
    let stats = null
    if (num) { const n = ok.map(Number).sort((a, b) => a - b), m = n.reduce((a, b) => a + b, 0) / n.length
      stats = { min: n[0], max: n[n.length - 1], mean: m, median: n.length % 2 ? n[(n.length - 1) / 2] : (n[n.length / 2 - 1] + n[n.length / 2]) / 2, std: Math.sqrt(n.reduce((a, b) => a + (b - m) ** 2, 0) / n.length) } }
    const missing = vals.length - ok.length
    if (type === 'empty') warnings.push(`Column "${name}" is entirely empty.`)
    else if (missing / vals.length > 0.2) warnings.push(`Column "${name}" is ${Math.round(100 * missing / vals.length)}% missing.`)
    return { name, type, missing, stats }
  })
  const seen = new Set(), unique = []
  body.forEach(r => { const k = JSON.stringify(r); if (!seen.has(k)) { seen.add(k); unique.push(r) } })
  const dupes = body.length - unique.length
  if (dupes) warnings.push(`${dupes} duplicate row(s) found.`)
  return { header, body, unique, cols, dupes, warnings }
}
export const toCSV = rows => rows.map(r => r.map(v => { const s = String(v ?? ''); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s }).join(',')).join('\r\n')
export function download(name, text, mime = 'text/csv;charset=utf-8') {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime })); a.download = name; a.click(); URL.revokeObjectURL(a.href)
}
