export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { bg: '#0B1120', side: '#111827', card: '#172033', primary: '#38BDF8', secondary: '#34D399', warning: '#FBBF24', ink: '#F8FAFC', muted: '#94A3B8', line: '#263449' } } },
  plugins: [],
}
