"""HTTP-level tests. They need `pip install -r requirements.txt`; they are skipped when FastAPI/httpx are missing."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    from fastapi.testclient import TestClient
    from app.main import create_app
    HAVE_API = True
except ImportError:  # pragma: no cover
    HAVE_API = False

REAL = Path(__file__).resolve().parent.parent / "data" / "forensic_tod_cleaned.csv"


@unittest.skipUnless(HAVE_API and REAL.is_file(), "fastapi/httpx or dataset not available")
class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(create_app())

    def get(self, url, **params):
        return self.client.get(url, params=params)

    def test_health(self):
        r = self.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["status"], "ok")
        self.assertEqual(r.json()["records"], 5000)

    def test_summary(self):
        d = self.get("/api/dataset/summary").json()["data"]
        self.assertEqual(d["rows"], 5000)
        self.assertTrue(d["is_synthetic"])

    def test_by_year_and_filters(self):
        r = self.get("/api/analytics/by-year", date_from="2024-01-01", date_to="2024-12-31").json()
        self.assertEqual(sum(b["count"] for b in r["data"]), r["meta"]["filtered_count"])
        self.assertEqual(r["meta"]["filtered_count"], 1226)

    def test_invalid_range_422(self):
        r = self.get("/api/analytics/overview", date_from="2025-02-01", date_to="2025-01-01")
        self.assertEqual(r.status_code, 422)
        self.assertIn("date_from", r.json()["detail"])

    def test_bad_date_format_422(self):
        self.assertEqual(self.get("/api/cases", date_from="31-12-2024").status_code, 422)

    def test_bad_month_422(self):
        self.assertEqual(self.get("/api/analytics/by-month", year=2024, month=13).status_code, 422)

    def test_drilldown(self):
        self.assertEqual(self.get("/api/analytics/drilldown", level="month").status_code, 422)
        m = self.get("/api/analytics/drilldown", level="month", year=2024).json()["data"]
        self.assertEqual(len(m["buckets"]), 12)
        c = self.get("/api/analytics/drilldown", level="cases", year=2024, month=3, page_size=5).json()["data"]
        self.assertLessEqual(len(c["cases"]["items"]), 5)

    def test_empty_result_is_200(self):
        r = self.get("/api/cases", date_from="1990-01-01", date_to="1990-01-31")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["data"]["total"], 0)

    def test_case_detail_and_errors(self):
        self.assertEqual(self.get("/api/cases/SYN-TOD-000001").status_code, 200)
        self.assertEqual(self.get("/api/cases/DOES-NOT-EXIST").status_code, 404)
        self.assertEqual(self.get("/api/cases/bad$id").status_code, 422)

    def test_pagination_limits(self):
        self.assertEqual(self.get("/api/cases", page_size=1000).status_code, 422)
        self.assertEqual(self.get("/api/cases", page=0).status_code, 422)

    def test_export_csv(self):
        r = self.get("/api/cases/export", year=2023, scene_type="outdoor")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.headers["content-type"].startswith("text/csv"))

    def test_cors_header(self):
        r = self.client.get("/api/health", headers={"Origin": "http://localhost:5173"})
        self.assertEqual(r.headers.get("access-control-allow-origin"), "http://localhost:5173")


@unittest.skipUnless(HAVE_API, "fastapi/httpx not available")
class MissingDatasetTests(unittest.TestCase):
    def test_degraded_health_and_503(self):
        import os
        os.environ["DATASET_PATH"] = "data/__missing__.csv"
        try:
            client = TestClient(create_app())
            self.assertEqual(client.get("/api/health").json()["status"], "degraded")
            self.assertEqual(client.get("/api/analytics/overview").status_code, 503)
        finally:
            os.environ.pop("DATASET_PATH", None)


if __name__ == "__main__":
    unittest.main()
