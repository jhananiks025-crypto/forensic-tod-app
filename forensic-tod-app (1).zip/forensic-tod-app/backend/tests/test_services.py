"""Data-layer tests (pandas only). Run:  python -m unittest discover -s tests   (or: pytest)"""
from __future__ import annotations

import json
import sys
import unittest
from datetime import date
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services import analytics as A  # noqa: E402
from app.services.dataset import DatasetError, build_dataset, load_csv  # noqa: E402
from app.services.filters import FilterError, Filters  # noqa: E402

REAL = Path(__file__).resolve().parent.parent / "data" / "forensic_tod_cleaned.csv"


def make_df(rows):
    """rows: list of (case_id, discovery_datetime, scene, location, temp, pmi)."""
    return pd.DataFrame([{
        "case_id": r[0], "discovery_datetime": r[1], "scene_type": r[2], "location_category": r[3],
        "ambient_temperature_c": r[4], "postmortem_interval_hours": r[5], "data_quality_status": "validated_complete",
        "data_origin": "synthetic", "observation_source": "police_officer",
    } for r in rows], dtype=str)


SMALL = make_df([
    ("C1", "2024-03-01T00:00:00Z", "indoor", "residential_bedroom", "20.0", "5.0"),
    ("C2", "2024-03-31T23:59:00Z", "outdoor", "roadside", "-3.5", "30.0"),
    ("C3", "2024-04-01T00:00:00Z", "indoor", "residential_bedroom", "10.0", "12.0"),
    ("C4", "2025-01-15T12:00:00Z", "outdoor", "wooded_area", "", ""),
    ("C5", "2024-03-31T23:30:00-05:00", "indoor", "commercial_building", "15.0", "8.0"),  # = 2024-04-01 04:30 UTC
])


class SmallDatasetTests(unittest.TestCase):
    def setUp(self):
        self.ds = build_dataset(SMALL.copy())

    def test_inclusive_date_range(self):
        r = A.list_cases(self.ds, Filters(date_from=date(2024, 3, 1), date_to=date(2024, 3, 31)).validate())
        self.assertEqual({i["case_id"] for i in r["data"]["items"]}, {"C1", "C2"})  # both boundary days included

    def test_end_date_excludes_next_day(self):
        r = A.list_cases(self.ds, Filters(date_to=date(2024, 3, 30)).validate())
        self.assertEqual({i["case_id"] for i in r["data"]["items"]}, {"C1"})

    def test_timezone_normalised_to_utc(self):
        r = A.by_month(self.ds, Filters(year=2024).validate())["data"]
        self.assertEqual([b["count"] for b in r if b["month"] in (3, 4)], [2, 2])  # C5 counts in April (UTC)

    def test_invalid_range_rejected(self):
        with self.assertRaises(FilterError):
            Filters(date_from=date(2024, 5, 1), date_to=date(2024, 4, 1)).validate()

    def test_bad_month_and_bounds_rejected(self):
        for bad in (Filters(month=13), Filters(temp_min=5, temp_max=5), Filters(pmi_min=9, pmi_max=2)):
            with self.assertRaises(FilterError):
                bad.validate()

    def test_range_outside_dataset(self):
        r = A.overview(self.ds, Filters(date_from=date(1990, 1, 1), date_to=date(1990, 12, 31)).validate())
        self.assertEqual(r["data"]["total_records"], 0)
        self.assertTrue(r["meta"]["range_outside_dataset"])
        self.assertIsNone(r["data"]["ambient_temperature_c"])

    def test_empty_results_are_graceful(self):
        f = Filters(year=1999, month=2).validate()
        d = A.drilldown(self.ds, f, "cases")["data"]
        self.assertTrue(d["empty"])
        self.assertEqual(d["cases"]["items"], [])
        self.assertEqual(d["cases"]["total_pages"], 1)
        self.assertTrue(A.drilldown(self.ds, Filters(year=1999).validate(), "month")["data"]["empty"])

    def test_drilldown_level_requirements(self):
        with self.assertRaises(FilterError):
            A.drilldown(self.ds, Filters(), "month")
        with self.assertRaises(FilterError):
            A.drilldown(self.ds, Filters(year=2024), "cases")
        with self.assertRaises(FilterError):
            A.drilldown(self.ds, Filters(), "decade")

    def test_missing_values_not_invented(self):
        r = A.get_case(self.ds, "C4")["data"]["fields"]
        self.assertIsNone(r["ambient_temperature_c"] if r["ambient_temperature_c"] != "" else None)
        t = A.temperature_distribution(self.ds, Filters())["data"]
        self.assertEqual(t["n_with_value"], 4)
        self.assertEqual(t["n_without_value"], 1)
        self.assertEqual(sum(b["count"] for b in t["bins"]), 4)

    def test_temperature_bin_filter_matches_bin_count(self):
        t = A.temperature_distribution(self.ds, Filters())["data"]
        for b in t["bins"]:
            n = A.list_cases(self.ds, Filters(temp_min=b["min"], temp_max=b["max"]))["data"]["total"]
            self.assertEqual(n, b["count"], b["label"])

    def test_pmi_bins_and_filter_agree(self):
        p = A.pmi_distribution(self.ds, Filters())["data"]
        self.assertTrue(p["available"])
        for b in p["bins"]:
            n = A.list_cases(self.ds, Filters(pmi_min=b["min"], pmi_max=b["max"]))["data"]["total"]
            self.assertEqual(n, b["count"], b["label"])

    def test_case_lookup(self):
        self.assertEqual(A.get_case(self.ds, "C1")["data"]["case_id"], "C1")
        with self.assertRaises(A.NotFoundError):
            A.get_case(self.ds, "NOPE")
        with self.assertRaises(FilterError):
            A.get_case(self.ds, "../../etc/passwd")

    def test_unparseable_dates_are_flagged_and_excluded_from_date_views(self):
        df = SMALL.copy()
        df.loc[0, "discovery_datetime"] = "not-a-date"
        ds = build_dataset(df)
        self.assertEqual(ds.validation["undated_records"], 1)
        self.assertEqual(A.by_year(ds, Filters())["meta"]["filtered_count"], 5)  # still in the dataset
        self.assertEqual(sum(b["count"] for b in A.by_year(ds, Filters())["data"]), 4)  # but not in any year

    def test_pmi_unavailable_when_no_valid_labels(self):
        df = SMALL.copy()
        df["postmortem_interval_hours"] = ""
        ds = build_dataset(df)
        r = A.pmi_distribution(ds, Filters())["data"]
        self.assertFalse(r["available"])
        self.assertEqual(r["bins"], [])

    def test_negative_pmi_and_implausible_temperature_excluded_not_altered(self):
        df = SMALL.copy()
        df.loc[0, "postmortem_interval_hours"] = "-4"
        df.loc[1, "ambient_temperature_c"] = "999"
        ds = build_dataset(df)
        self.assertEqual(ds.validation["negative_pmi_values"], 1)
        self.assertEqual(ds.validation["implausible_temperature_values"], 1)
        self.assertEqual(A.get_case(ds, "C2")["data"]["fields"]["ambient_temperature_c"], 999.0)  # original preserved

    def test_required_column_missing(self):
        with self.assertRaises(DatasetError):
            build_dataset(SMALL.drop(columns=["discovery_datetime"]))

    def test_empty_dataset(self):
        with self.assertRaises(DatasetError):
            build_dataset(SMALL.iloc[0:0])

    def test_invalid_sort_and_pagination(self):
        with self.assertRaises(FilterError):
            A.list_cases(self.ds, Filters(), sort_by="__class__")
        with self.assertRaises(FilterError):
            A.list_cases(self.ds, Filters(), page=0)
        with self.assertRaises(FilterError):
            A.list_cases(self.ds, Filters(), page_size=100000)

    def test_outputs_are_json_safe(self):
        for out in (A.overview(self.ds, Filters()), A.list_cases(self.ds, Filters()), A.data_quality(self.ds, Filters()),
                    A.temperature_distribution(self.ds, Filters()), A.drilldown(self.ds, Filters(), "year")):
            json.dumps(out, allow_nan=False)


class FileErrorTests(unittest.TestCase):
    def test_missing_file(self):
        with self.assertRaises(DatasetError):
            load_csv(Path("/nonexistent/none.csv"))

    def test_wrong_extension(self):
        with self.assertRaises(DatasetError):
            load_csv(Path(__file__))


@unittest.skipUnless(REAL.is_file(), "dataset not present in backend/data/")
class RealDatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ds = load_csv(REAL)

    def test_loads_and_validates(self):
        self.assertEqual(len(self.ds.df), 5000)
        self.assertTrue(self.ds.validation["valid"])
        self.assertTrue(self.ds.is_synthetic)
        self.assertEqual(self.ds.pmi_valid_count, 5000)

    def test_year_totals_match_dataset(self):
        years = A.by_year(self.ds, Filters())["data"]
        self.assertEqual(sum(b["count"] for b in years), 5000)

    def test_year_to_month_to_case_consistency(self):
        for y in (2022, 2023, 2024, 2025):
            year_n = next(b["count"] for b in A.by_year(self.ds, Filters())["data"] if b["year"] == y)
            months = A.drilldown(self.ds, Filters(year=y), "month")["data"]["buckets"]
            self.assertEqual(sum(b["count"] for b in months), year_n)
            for b in months:
                d = A.drilldown(self.ds, Filters(year=y, month=b["month"]), "cases", page_size=200)["data"]
                self.assertEqual(d["cases"]["total"], b["count"])
                for item in d["cases"]["items"]:
                    self.assertTrue(item["discovery_datetime"].startswith(f"{y}-{b['month']:02d}"), item)

    def test_pagination_has_no_duplicates_or_gaps(self):
        f = Filters(year=2024, month=3)
        seen, page = [], 1
        while True:
            r = A.list_cases(self.ds, f, page=page, page_size=40)["data"]
            seen += [i["case_id"] for i in r["items"]]
            if page >= r["total_pages"]:
                break
            page += 1
        self.assertEqual(len(seen), len(set(seen)))
        self.assertEqual(len(seen), A.list_cases(self.ds, f)["data"]["total"])

    def test_date_range_combined_with_drilldown(self):
        f = Filters(date_from=date(2024, 3, 10), date_to=date(2024, 3, 20), year=2024, month=3).validate()
        d = A.drilldown(self.ds, f, "cases", page_size=200)["data"]["cases"]
        self.assertGreater(d["total"], 0)
        for i in d["items"]:
            self.assertTrue("2024-03-10" <= i["discovery_datetime"][:10] <= "2024-03-20")
        # a year drill-down must not escape the date range
        months = A.drilldown(self.ds, Filters(date_from=date(2024, 3, 10), date_to=date(2024, 3, 20), year=2024), "month")["data"]["buckets"]
        self.assertEqual(sum(b["count"] for b in months), d["total"])
        self.assertTrue(all(b["count"] == 0 for b in months if b["month"] != 3))

    def test_scene_filter_applies_everywhere(self):
        f = Filters(scene_type="indoor")
        total = A.overview(self.ds, f)["data"]["total_records"]
        self.assertEqual(sum(b["count"] for b in A.by_year(self.ds, f)["data"]), total)
        self.assertEqual(A.by_scene(self.ds, f)["data"], [{"key": "indoor", "label": "indoor", "count": total, "pct": 100.0}])
        self.assertEqual(sum(b["count"] for b in A.by_location(self.ds, f)["data"]), total)

    def test_distribution_totals(self):
        self.assertEqual(sum(b["count"] for b in A.temperature_distribution(self.ds, Filters())["data"]["bins"]), 5000)
        self.assertEqual(sum(b["count"] for b in A.pmi_distribution(self.ds, Filters())["data"]["bins"]), 5000)

    def test_export_matches_filter(self):
        f = Filters(year=2023, scene_type="outdoor")
        text, n = A.export_cases_csv(self.ds, f)
        self.assertEqual(len(text.strip().splitlines()) - 1, n)
        self.assertEqual(n, A.list_cases(self.ds, f)["data"]["total"])
        with self.assertRaises(FilterError):
            A.export_cases_csv(self.ds, Filters(), max_rows=10)


if __name__ == "__main__":
    unittest.main()
