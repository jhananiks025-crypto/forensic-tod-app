# Forensic TOD – Analytics Backend (FastAPI)

Serves **descriptive analytics** over the supplied historical-incident CSV. It does **not** contain or claim a time-of-death
prediction model. `postmortem_interval_hours` and `reference_estimated_death_datetime` are dataset reference labels, shown
descriptively only and never used as inputs to anything.

## Setup (Windows PowerShell, VS Code terminal)
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env                 # optional; defaults already work
```
Place your dataset at **`backend/data/forensic_tod_cleaned.csv`** (or set `DATASET_PATH` in `.env`; relative paths are resolved from `backend/`).

## Run
```powershell
uvicorn app.main:app --reload --port 8000
```
Interactive docs: http://localhost:8000/docs. If the dataset is missing the server still starts; `/api/health` reports `degraded`
and data endpoints return HTTP 503 with an explanatory message.

## Configuration (`.env`)
| Variable | Default | Meaning |
|---|---|---|
| `DATASET_PATH` | `data/forensic_tod_cleaned.csv` | CSV to serve (set on the server only – never accepted from requests) |
| `CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` | Allowed frontend origins |
| `LOG_LEVEL` | `INFO` | Python logging level |

## Tests
```powershell
python -m unittest discover -s tests -v     # or: pytest
```
`tests/test_services.py` needs only pandas. `tests/test_api.py` needs the packages in `requirements.txt` and is skipped otherwise.

## Layout
```
app/main.py            app factory, CORS, error handlers, request logging
app/config.py          settings (env / .env)
app/routes/            thin HTTP layer: system.py, analytics.py, cases.py, deps.py (filter parsing)
app/services/          dataset.py (load/validate/cache), filters.py, analytics.py (all computation, no FastAPI imports)
app/schemas/common.py  response envelopes
tests/                 unit + API tests
```
The CSV is parsed once and cached; it is re-read only if the file's modification time changes. All values are read as text so
nothing is silently coerced; analysis-only numeric/date columns are derived separately and original values are never altered.

## Column mapping (application field → CSV column)
Same names in both. **Required:** `case_id`, `scene_type`, `location_category`, `discovery_datetime` (primary date for filtering
and drill-down). **Optional (features degrade if absent):** `ambient_temperature_c`, `body_temperature_c`, `relative_humidity_pct`,
`postmortem_interval_hours`, `data_quality_status`, `observation_source`, `last_known_alive_datetime`, `reported_datetime`,
`observation_datetime`, `environmental_conditions`, `clothing_covering`, `professional_examination_available`, `data_origin`,
`data_source_type`, `reference_label_source`, `reference_estimated_death_datetime`, `suggested_split`.

Data rules: dates are ISO-8601, normalised to **UTC**; filtering and grouping use UTC calendar days. Unparseable discovery dates keep
the record in the dataset but exclude it from date views (reported as a warning). Ambient temperatures outside −60…70 °C and negative PMI
values are excluded from statistics only (reported, not altered). `not_applicable` cells are counted as "not applicable", not "missing".
A PMI chart is offered only when valid PMI values exist.

## API
All data endpoints are `GET`. Analytics/case-list responses use `{"meta": {...}, "data": ...}`; `meta` carries `filtered_count`,
`dataset_total`, `applied_filters`, `dataset_date_range`, `date_basis` and (when a date range is used) `range_outside_dataset`.

### Common filter parameters
| Param | Type | Notes |
|---|---|---|
| `date_from`, `date_to` | `YYYY-MM-DD` | Inclusive on both ends; `date_from > date_to` → 422 |
| `year`, `month` | int, month 1–12 | Drill-down state |
| `scene_type`, `location_category`, `data_quality_status`, `observation_source` | text | Exact match; valid values are in `/api/dataset/summary` → `filter_options` |
| `temp_min`, `temp_max` | float | Ambient °C; **min inclusive, max exclusive** |
| `pmi_min`, `pmi_max` | float ≥ 0 | PMI hours; **min inclusive, max exclusive** |
| `q` | text | Case-ID substring |

| Endpoint | Description |
|---|---|
| `/api/health` | `{status: ok\|degraded, dataset_loaded, records, dataset_file, error}` (always 200) |
| `/api/dataset/summary` | Rows, columns, date range, column mapping, per-column quality, validation messages, `filter_options`, synthetic-data notice |
| `/api/analytics/overview` | Summary-card figures: total, date span, temperature stats, PMI stats, complete-record share |
| `/api/analytics/by-year` | Count per year (ignores `year`/`month`, which are drill-down state) |
| `/api/analytics/by-month` | 12 months of `year`; without `year`, a year-month timeline over the dataset span |
| `/api/analytics/by-scene`, `/by-location` | Counts with percentages |
| `/api/analytics/temperature-distribution` | 5 °C bins; `data.available=false` + `reason` if no temperatures |
| `/api/analytics/pmi-distribution` | Hour bins (0–6, 6–12, 12–24, 24–48, 48–96, 96+); `data.available=false` + `reason` if no valid PMI labels |
| `/api/analytics/data-quality` | Quality-status counts and per-field available / not applicable / missing |
| `/api/analytics/drilldown?level=year\|month\|cases` | `month` needs `year`; `cases` needs `year` and `month`. Returns `breadcrumb`, `buckets` or paginated `cases`, `empty` |
| `/api/cases` | Paginated list: `page`, `page_size` (1–200, default 25), `sort_by`, `sort_dir` + filters |
| `/api/cases/export` | CSV of the filtered list (capped at 50,000 rows) |
| `/api/cases/{case_id}` | Full record (404 if unknown, 422 for malformed IDs) |

Errors: `422` invalid parameter/combination, `404` unknown case, `503` dataset unavailable. Body: `{"detail": "..."}`.

## Known limitations
No database (CSV only; PostgreSQL is not integrated). No CSV upload to the server (the Data Explorer's browser-side upload is unchanged).
Case records are read-only. No authentication – run locally or behind your own access control. Single-process in-memory cache.
