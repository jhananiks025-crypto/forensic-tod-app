"""Response schemas. Every analytics/case endpoint returns {"meta": ..., "data": ...}."""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel


class Envelope(BaseModel):
    meta: dict
    data: Any


class CaseEnvelope(BaseModel):
    data: Any


class Health(BaseModel):
    status: str                      # "ok" or "degraded"
    dataset_loaded: bool
    records: Optional[int] = None
    dataset_file: Optional[str] = None
    error: Optional[str] = None
