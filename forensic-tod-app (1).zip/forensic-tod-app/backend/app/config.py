"""Backend configuration. Values come from environment variables or an optional backend/.env file."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parent.parent


def _load_env_file(path: Path) -> None:
    """Tiny .env reader (KEY=VALUE lines). Real environment variables always win."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


@dataclass(frozen=True)
class Settings:
    dataset_path: Path
    cors_origins: tuple
    log_level: str
    max_page_size: int = 200
    max_export_rows: int = 50_000


def get_settings() -> Settings:
    _load_env_file(BACKEND_ROOT / ".env")
    raw = os.environ.get("DATASET_PATH", "data/forensic_tod_cleaned.csv")
    path = Path(raw)
    if not path.is_absolute():
        path = BACKEND_ROOT / path
    origins = os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    return Settings(
        dataset_path=path.resolve(),
        cors_origins=tuple(o.strip() for o in origins.split(",") if o.strip()),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    )
