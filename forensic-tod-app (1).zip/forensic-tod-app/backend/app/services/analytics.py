"""Aggregations and record queries. Pure pandas, no web-framework imports."""
from __future__ import annotations

import calendar
import io
import math
import re
from typing import Optional

import numpy as np
import pandas as pd

from .dataset import NOT_APPLICABLE, TARGET_DERIVED, Dataset
from .filters import FilterError, Filters, apply_filters

LIST_FIELDS = ["case_id", "discovery_datetime", "scene_type", "location_category", "ambient_temperature_c",
               "postmortem_interval_hours", "data_quality_status", "observation_source"]
SORTABLE = {"case_id", "discovery_datetime", "scene_type", "location_category", "ambient_temperature_c",
            "postmortem_interval_hours", "data_quality_status", "observation_source"}
PMI_EDGES = [0, 6, 12, 24, 48, 96]          # hours; last bin is open-ended
TEMP_BIN_WIDTH = 5                          # °C
CASE_ID_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
QUALITY_FIELDS = [
    ("ambient_temperature_c", "Ambient temperature"), ("body_temperature_c", "Body temperature"),
    ("relative_humidity_pct", "Relative humidity"), ("postmortem_interval_hours", "PMI reference label"),
    ("last_known_alive_datetime", "Last known alive"), ("reported_datetime", "Report time"),
    ("observation_datetime", "Observation time"), ("environmental_conditions", "Environmental conditions"),
    ("clothing_covering", "Clothing / covering"), ("professional_examination_available", "Professional examination"),
]


class NotFoundError(LookupError):
    """Requested case does not exist (HTTP 404)."""


def _py(v):
    """numpy/pandas scalar -> JSON-safe Python value (NaN/NaT -> None)."""
    if v is None or v is pd.NaT:
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating, float)):
        return None if math.isnan(v) or math.isinf(v) else float(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def _pretty(key: str) -> str:
    return str(key).replace("_", " ")


def meta(ds: Dataset, sub: pd.DataFrame, f: Filters, extra: Optional[dict] = None) -> dict:
    out = {"filtered_count": int(len(sub)), "dataset_total": int(len(ds.df)), "applied_filters": f.describe(),
           "dataset_date_range": date_range(ds), "date_basis": "discovery_datetime (UTC calendar dates)"}
    if f.date_from or f.date_to:
        rng = date_range(ds)
        lo, hi = rng["min"], rng["max"]
        out["range_outside_dataset"] = bool(lo and hi and (
            (f.date_to is not None and f.date_to.isoformat() < lo) or (f.date_from is not None and f.date_from.isoformat() > hi)))
    if extra:
        out.update(extra)
    return out


def date_range(ds: Dataset) -> dict:
    d = ds.disc.dropna()
    if d.empty:
        return {"min": None, "max": None}
    return {"min": d.min().date().isoformat(), "max": d.max().date().isoformat()}


def dataset_summary(ds: Dataset) -> dict:
    return {
        "file_name": ds.file_name, "loaded_at": ds.loaded_at, "rows": int(len(ds.df)), "columns": int(ds.df.shape[1]),
        "is_synthetic": ds.is_synthetic,
        "data_notice": ("Synthetic educational data (data_origin = synthetic). Not real casework; do not use to "
                        "draw forensic conclusions." if ds.is_synthetic else None),
        "date_basis": "discovery_datetime (UTC)", "date_range": date_range(ds),
        "column_mapping": ds.mapping, "missing_optional_fields": ds.missing_fields,
        "target_derived_columns": [c for c in TARGET_DERIVED if c in ds.df.columns],
        "target_note": ("postmortem_interval_hours and reference_estimated_death_datetime are reference labels. "
                        "They are used for descriptive analytics only and must never be model inputs."),
        "pmi_available": ds.pmi_valid_count > 0, "pmi_valid_count": ds.pmi_valid_count,
        "filter_options": {k: sorted(ds.df[ds.mapping[k]].unique().tolist())
                           for k in ("scene_type", "location_category", "data_quality_status", "observation_source") if k in ds.mapping},
        "columns_info": ds.columns_info, "validation": ds.validation,
        "model_status": "No validated prediction model is connected. Analytics here are descriptive only.",
    }


def _counts(series: pd.Series, total: int) -> list:
    vc = series.value_counts()
    return [{"key": str(k), "label": _pretty(k), "count": int(v), "pct": round(100 * v / total, 1) if total else 0.0}
            for k, v in vc.items()]


def _stats(s: pd.Series) -> Optional[dict]:
    s = s.dropna()
    if s.empty:
        return None
    return {"n": int(len(s)), "mean": round(float(s.mean()), 2), "median": round(float(s.median()), 2),
            "min": round(float(s.min()), 2), "max": round(float(s.max()), 2)}


def overview(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    idx = sub.index
    q = ds.mapping.get("data_quality_status")
    complete = int((sub[q] == "validated_complete").sum()) if q else None
    d = ds.disc.loc[idx].dropna()
    return {"meta": meta(ds, sub, f), "data": {
        "total_records": int(len(sub)),
        "date_range": {"min": d.min().date().isoformat() if len(d) else None, "max": d.max().date().isoformat() if len(d) else None},
        "scene_types": int(sub[ds.mapping["scene_type"]].nunique()),
        "location_categories": int(sub[ds.mapping["location_category"]].nunique()),
        "ambient_temperature_c": _stats(ds.temp.loc[idx]),
        "pmi_hours": _stats(ds.pmi.loc[idx]) if ds.pmi_valid_count else None,
        "pmi_available": ds.pmi_valid_count > 0,
        "complete_records": complete,
        "complete_pct": round(100 * complete / len(sub), 1) if (complete is not None and len(sub)) else None,
    }}


def _year_span(ds: Dataset) -> range:
    y = ds.year.dropna()
    return range(int(y.min()), int(y.max()) + 1)


def by_year(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f, ignore=("year", "month"))   # year/month are drill-down state, not chart filters
    counts = ds.year.loc[sub.index].dropna().astype(int).value_counts()
    buckets = [{"key": str(y), "label": str(y), "year": y, "count": int(counts.get(y, 0))} for y in _year_span(ds)]
    return {"meta": meta(ds, sub, f), "data": buckets}


def by_month(ds: Dataset, f: Filters) -> dict:
    """Months of `year` (12 buckets) when a year is given; otherwise a year-month timeline over the dataset span."""
    if f.year is not None:
        sub = apply_filters(ds, f, ignore=("month",))
        counts = ds.month.loc[sub.index].dropna().astype(int).value_counts()
        buckets = [{"key": f"{f.year}-{m:02d}", "label": calendar.month_abbr[m], "year": f.year, "month": m,
                    "count": int(counts.get(m, 0))} for m in range(1, 13)]
    else:
        sub = apply_filters(ds, f)
        ym = pd.DataFrame({"y": ds.year.loc[sub.index], "m": ds.month.loc[sub.index]}).dropna().astype(int)
        counts = ym.groupby(["y", "m"]).size()
        buckets = [{"key": f"{y}-{m:02d}", "label": f"{calendar.month_abbr[m]} {y}", "year": y, "month": m,
                    "count": int(counts.get((y, m), 0))} for y in _year_span(ds) for m in range(1, 13)]
    return {"meta": meta(ds, sub, f), "data": buckets}


def by_scene(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    return {"meta": meta(ds, sub, f), "data": _counts(sub[ds.mapping["scene_type"]], len(sub))}


def by_location(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    return {"meta": meta(ds, sub, f), "data": _counts(sub[ds.mapping["location_category"]], len(sub))}


def _binned(values: pd.Series, edges: list) -> list:
    out = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        cnt = int(((values >= lo) & ((values < hi) if hi is not None else True)).sum())
        out.append((lo, hi, cnt))
    return out


def temperature_distribution(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    t = ds.temp.loc[sub.index]
    vals = t.dropna()
    if "ambient_temperature_c" not in ds.mapping or ds.temp.notna().sum() == 0:
        return {"meta": meta(ds, sub, f), "data": {"available": False, "reason": "The dataset has no usable ambient temperature values.", "bins": []}}
    # bin edges span the whole dataset so the axis stays stable while filters change
    lo = math.floor(ds.temp.min() / TEMP_BIN_WIDTH) * TEMP_BIN_WIDTH
    hi = (math.floor(ds.temp.max() / TEMP_BIN_WIDTH) + 1) * TEMP_BIN_WIDTH
    edges = list(range(int(lo), int(hi) + 1, TEMP_BIN_WIDTH))
    bins = [{"label": f"{a} to {b}", "min": a, "max": b, "count": c} for a, b, c in _binned(vals, edges)]
    return {"meta": meta(ds, sub, f), "data": {
        "available": True, "unit": "°C", "bin_width": TEMP_BIN_WIDTH, "bin_rule": "min inclusive, max exclusive",
        "n_with_value": int(len(vals)), "n_without_value": int(len(t) - len(vals)), "stats": _stats(t), "bins": bins}}


def pmi_distribution(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    if ds.pmi_valid_count == 0:
        return {"meta": meta(ds, sub, f), "data": {"available": False, "bins": [],
                "reason": "No valid postmortem_interval_hours values exist in the dataset, so no PMI distribution can be drawn."}}
    p = ds.pmi.loc[sub.index]
    vals = p.dropna()
    edges = PMI_EDGES + [None]
    bins = []
    for lo, hi, c in _binned(vals, edges):
        label = f"{lo}+ h" if hi is None else f"{lo}–{hi} h"
        bins.append({"label": label, "min": lo, "max": hi, "count": c})
    label_col = ds.mapping.get("reference_label_source")
    sources = sorted(sub[label_col].unique().tolist()) if label_col and len(sub) else []
    return {"meta": meta(ds, sub, f), "data": {
        "available": True, "unit": "hours", "bin_rule": "min inclusive, max exclusive", "n_with_value": int(len(vals)),
        "stats": _stats(p), "label_sources": sources,
        "note": ("PMI values are reference labels from the dataset" + (" (synthetic, simulated timelines)" if ds.is_synthetic else "")
                 + ". This is a descriptive histogram, not a model prediction."),
        "bins": bins}}


def data_quality(ds: Dataset, f: Filters) -> dict:
    sub = apply_filters(ds, f)
    n = len(sub)
    fields = []
    for key, label in QUALITY_FIELDS:
        col = ds.mapping.get(key)
        if not col:
            fields.append({"field": key, "label": label, "column_present": False, "available": 0, "not_applicable": 0, "missing": n, "pct_available": None})
            continue
        s = sub[col]
        blank = s.isna() | (s.str.strip() == "")
        na = (s.str.strip().str.lower() == NOT_APPLICABLE) & ~blank
        avail = int((~blank & ~na).sum())
        fields.append({"field": key, "label": label, "column_present": True, "available": avail, "not_applicable": int(na.sum()),
                       "missing": int(blank.sum()), "pct_available": round(100 * avail / n, 1) if n else None})
    qcol = ds.mapping.get("data_quality_status")
    return {"meta": meta(ds, sub, f), "data": {
        "status_counts": _counts(sub[qcol], n) if qcol else [], "fields": fields,
        "note": "'not applicable' means the field is intentionally not recorded for that record; 'missing' means blank."}}


# ---------- records ----------
def _numeric_columns(ds: Dataset) -> set:
    return {i["name"] for i in ds.columns_info if i["type"] == "numeric"}


def _out(value, column: str, numeric: set):
    """Serialise a raw string cell: numeric columns become numbers; 'not_applicable'/blank text is kept as-is."""
    if column in numeric:
        n = pd.to_numeric(pd.Series([value]), errors="coerce").iloc[0]
        if not pd.isna(n):
            return _py(n)
    return _py(value)


def _record(row: pd.Series, ds: Dataset, cols: list) -> dict:
    num = _numeric_columns(ds)
    return {c: _out(row[ds.mapping[c]], ds.mapping[c], num) if c in ds.mapping else None for c in cols}


def _sorted(ds: Dataset, sub: pd.DataFrame, sort_by: str, sort_dir: str) -> pd.DataFrame:
    if sort_by not in SORTABLE:
        raise FilterError(f"sort_by must be one of: {', '.join(sorted(SORTABLE))}.")
    if sort_dir not in ("asc", "desc"):
        raise FilterError("sort_dir must be 'asc' or 'desc'.")
    key = {"discovery_datetime": ds.disc, "ambient_temperature_c": ds.temp, "postmortem_interval_hours": ds.pmi}.get(sort_by)
    tmp = sub.copy()
    tmp["_k"] = key.loc[sub.index] if key is not None else sub[ds.mapping[sort_by]]
    tmp["_id"] = sub[ds.mapping["case_id"]]
    asc = sort_dir == "asc"
    return tmp.sort_values(["_k", "_id"], ascending=[asc, True], na_position="last", kind="mergesort")


def list_cases(ds: Dataset, f: Filters, page: int = 1, page_size: int = 25, sort_by: str = "discovery_datetime",
               sort_dir: str = "asc", max_page_size: int = 200) -> dict:
    if page < 1:
        raise FilterError("page must be 1 or greater.")
    if not 1 <= page_size <= max_page_size:
        raise FilterError(f"page_size must be between 1 and {max_page_size}.")
    sub = apply_filters(ds, f)
    ordered = _sorted(ds, sub, sort_by, sort_dir)
    total = len(ordered)
    pages = max(1, math.ceil(total / page_size))
    chunk = ordered.iloc[(page - 1) * page_size: page * page_size]
    items = [_record(r, ds, LIST_FIELDS) for _, r in chunk.iterrows()]
    return {"meta": meta(ds, sub, f), "data": {"page": page, "page_size": page_size, "total": total, "total_pages": pages,
            "sort_by": sort_by, "sort_dir": sort_dir, "items": items}}


def get_case(ds: Dataset, case_id: str) -> dict:
    if not CASE_ID_RE.match(case_id or ""):
        raise FilterError("case_id contains invalid characters or is too long.")
    rows = ds.df[ds.df[ds.mapping["case_id"]] == case_id]
    if rows.empty:
        raise NotFoundError(f"Case '{case_id}' was not found.")
    row = rows.iloc[0]
    num = _numeric_columns(ds)
    rec = {c: _out(v, c, num) for c, v in row.items()}
    return {"data": {
        "case_id": case_id, "fields": rec, "is_synthetic": ds.is_synthetic,
        "target_derived_columns": [c for c in TARGET_DERIVED if c in rec],
        "notice": "Reference labels (PMI, reference death time) are dataset labels, not a prediction or a verified finding."}}


def export_cases_csv(ds: Dataset, f: Filters, max_rows: int = 50_000) -> tuple:
    sub = apply_filters(ds, f)
    if len(sub) > max_rows:
        raise FilterError(f"Export is limited to {max_rows} rows; narrow the filters (matched {len(sub)}).")
    ordered = _sorted(ds, sub, "discovery_datetime", "asc")
    cols = [ds.mapping[c] for c in LIST_FIELDS if c in ds.mapping]
    buf = io.StringIO()
    ordered[cols].to_csv(buf, index=False)
    return buf.getvalue(), int(len(sub))


# ---------- drill-down ----------
def drilldown(ds: Dataset, f: Filters, level: str, page: int = 1, page_size: int = 25,
              sort_by: str = "discovery_datetime", sort_dir: str = "asc", max_page_size: int = 200) -> dict:
    """level='year' -> buckets per year; 'month' -> buckets per month of f.year; 'cases' -> records of f.year/f.month."""
    if level not in ("year", "month", "cases"):
        raise FilterError("level must be 'year', 'month' or 'cases'.")
    if level in ("month", "cases") and f.year is None:
        raise FilterError("A year is required for the 'month' and 'cases' levels.")
    if level == "cases" and f.month is None:
        raise FilterError("A month is required for the 'cases' level.")
    crumbs = [{"level": "year", "label": "All years"}]
    if f.year is not None and level in ("month", "cases"):
        crumbs.append({"level": "month", "label": str(f.year), "year": f.year})
    if f.month is not None and level == "cases":
        crumbs.append({"level": "cases", "label": calendar.month_name[f.month], "year": f.year, "month": f.month})
    if level == "year":
        res = by_year(ds, f)
        return {"meta": res["meta"], "data": {"level": level, "breadcrumb": crumbs, "buckets": res["data"], "cases": None,
                "empty": res["meta"]["filtered_count"] == 0}}
    if level == "month":
        res = by_month(ds, f)
        return {"meta": res["meta"], "data": {"level": level, "breadcrumb": crumbs, "buckets": res["data"], "cases": None,
                "empty": sum(b["count"] for b in res["data"]) == 0}}
    res = list_cases(ds, f, page, page_size, sort_by, sort_dir, max_page_size)
    return {"meta": res["meta"], "data": {"level": level, "breadcrumb": crumbs, "buckets": None, "cases": res["data"],
            "empty": res["data"]["total"] == 0}}
