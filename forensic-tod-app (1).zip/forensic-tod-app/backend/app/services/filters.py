"""Filter model, validation and application. No web-framework imports so it can be unit-tested alone."""
from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import date, timedelta
from typing import Iterable, Optional

import pandas as pd

from .dataset import Dataset


class FilterError(ValueError):
    """The request contained an invalid filter combination (mapped to HTTP 422)."""


@dataclass(frozen=True)
class Filters:
    date_from: Optional[date] = None   # inclusive, UTC calendar date of discovery_datetime
    date_to: Optional[date] = None     # inclusive
    year: Optional[int] = None
    month: Optional[int] = None
    scene_type: Optional[str] = None
    location_category: Optional[str] = None
    data_quality_status: Optional[str] = None
    observation_source: Optional[str] = None
    temp_min: Optional[float] = None   # ambient °C, inclusive lower bound
    temp_max: Optional[float] = None   # ambient °C, EXCLUSIVE upper bound
    pmi_min: Optional[float] = None    # PMI hours, inclusive lower bound
    pmi_max: Optional[float] = None    # PMI hours, EXCLUSIVE upper bound
    q: Optional[str] = None            # case-id substring search

    def validate(self) -> "Filters":
        if self.date_from and self.date_to and self.date_from > self.date_to:
            raise FilterError("date_from must not be after date_to.")
        if self.month is not None and not 1 <= self.month <= 12:
            raise FilterError("month must be between 1 and 12.")
        if self.year is not None and not 1000 <= self.year <= 9999:
            raise FilterError("year must be a four-digit year.")
        if self.temp_min is not None and self.temp_max is not None and self.temp_min >= self.temp_max:
            raise FilterError("temp_min must be lower than temp_max.")
        if self.pmi_min is not None and self.pmi_max is not None and self.pmi_min >= self.pmi_max:
            raise FilterError("pmi_min must be lower than pmi_max.")
        return self

    def describe(self) -> dict:
        out = {}
        for f in fields(self):
            v = getattr(self, f.name)
            if v is not None and v != "":
                out[f.name] = v.isoformat() if isinstance(v, date) else v
        return out


def apply_filters(ds: Dataset, f: Filters, ignore: Iterable[str] = ()) -> pd.DataFrame:
    """Return the matching rows. `ignore` lists filter names to skip (used for drill-down context charts)."""
    skip = set(ignore)
    df = ds.df
    mask = pd.Series(True, index=df.index)

    def on(name: str) -> bool:
        return name not in skip and getattr(f, name) is not None and getattr(f, name) != ""

    if on("date_from"):
        mask &= ds.disc >= pd.Timestamp(f.date_from, tz="UTC")
    if on("date_to"):  # inclusive end date -> strictly before the next midnight (UTC)
        mask &= ds.disc < pd.Timestamp(f.date_to + timedelta(days=1), tz="UTC")
    if on("year"):
        mask &= ds.year == f.year
    if on("month"):
        mask &= ds.month == f.month
    for name in ("scene_type", "location_category", "data_quality_status", "observation_source"):
        if on(name):
            col = ds.mapping.get(name)
            if col is None:
                raise FilterError(f"Filter '{name}' is not supported: the dataset has no matching column.")
            mask &= df[col] == getattr(f, name)
    if on("temp_min"):
        mask &= ds.temp >= f.temp_min
    if on("temp_max"):
        mask &= ds.temp < f.temp_max
    if on("pmi_min"):
        mask &= ds.pmi >= f.pmi_min
    if on("pmi_max"):
        mask &= ds.pmi < f.pmi_max
    if on("q"):
        mask &= df[ds.mapping["case_id"]].str.contains(f.q.strip(), case=False, regex=False, na=False)
    return df[mask.fillna(False).astype(bool)]
