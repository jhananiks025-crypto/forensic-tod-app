"""Dataset loading, validation and caching.

The CSV is read once and cached in memory. It is re-read only when the file's modification time changes.
Original values are never modified: derived, analysis-only columns live in separate Series on the Dataset.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


class DatasetError(Exception):
    """The dataset is missing, unreadable or fails mandatory validation (mapped to HTTP 503)."""


# application field -> CSV column (documented in backend/README.md)
COLUMN_MAP = {
    "case_id": "case_id",
    "scene_type": "scene_type",
    "location_category": "location_category",
    "discovery_datetime": "discovery_datetime",          # primary date used for filtering and drill-down
    "last_known_alive_datetime": "last_known_alive_datetime",
    "reported_datetime": "reported_datetime",
    "observation_datetime": "observation_datetime",
    "ambient_temperature_c": "ambient_temperature_c",
    "body_temperature_c": "body_temperature_c",
    "relative_humidity_pct": "relative_humidity_pct",
    "postmortem_interval_hours": "postmortem_interval_hours",   # reference label (target), analytics only
    "reference_estimated_death_datetime": "reference_estimated_death_datetime",  # target-derived
    "data_quality_status": "data_quality_status",
    "observation_source": "observation_source",
    "professional_examination_available": "professional_examination_available",
    "environmental_conditions": "environmental_conditions",
    "clothing_covering": "clothing_covering",
    "data_origin": "data_origin",
    "data_source_type": "data_source_type",
    "reference_label_source": "reference_label_source",
    "suggested_split": "suggested_split",
}
REQUIRED_FIELDS = ("case_id", "scene_type", "location_category", "discovery_datetime")
# Columns derived from the target; they must never be used as model inputs.
TARGET_DERIVED = ("postmortem_interval_hours", "reference_estimated_death_datetime")
TEMP_PLAUSIBLE = (-60.0, 70.0)   # °C, same range the case form uses
NOT_APPLICABLE = "not_applicable"


@dataclass
class Dataset:
    df: pd.DataFrame
    mapping: dict            # app field -> actual column present in the file
    missing_fields: list     # app fields whose column is absent
    disc: pd.Series          # discovery datetime, UTC (NaT where unparseable)
    year: pd.Series
    month: pd.Series
    temp: pd.Series          # ambient °C, NaN if missing/implausible
    pmi: pd.Series           # PMI hours, NaN if missing/negative
    validation: dict
    columns_info: list
    file_name: str
    loaded_at: str
    mtime: float

    @property
    def pmi_valid_count(self) -> int:
        return int(self.pmi.notna().sum())

    @property
    def is_synthetic(self) -> bool:
        col = self.mapping.get("data_origin")
        return bool(col) and bool((self.df[col].str.lower() == "synthetic").all())


def _num(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def _col_info(df: pd.DataFrame) -> list:
    info = []
    for name in df.columns:
        s = df[name]
        blank = s.isna() | (s.str.strip() == "")
        na = (s.str.strip().str.lower() == NOT_APPLICABLE) & ~blank
        present = s[~blank & ~na]
        nums = _num(present)
        if len(present) and nums.notna().all():
            kind = "numeric"
        elif len(present) and pd.to_datetime(present, utc=True, errors="coerce", format="ISO8601").notna().all():
            kind = "datetime"
        else:
            kind = "text"
        info.append({"name": name, "type": kind, "missing": int(blank.sum()), "not_applicable": int(na.sum()),
                     "available": int(len(present))})
    return info


def build_dataset(df: pd.DataFrame, file_name: str = "in-memory", mtime: float = 0.0) -> Dataset:
    """Validate a raw all-string DataFrame and derive analysis columns. Raises DatasetError on fatal problems."""
    mapping = {k: v for k, v in COLUMN_MAP.items() if v in df.columns}
    missing_fields = [k for k in COLUMN_MAP if k not in mapping]
    fatal = [f for f in REQUIRED_FIELDS if f not in mapping]
    if fatal:
        raise DatasetError("Dataset is missing required column(s): " + ", ".join(COLUMN_MAP[f] for f in fatal))
    if df.empty:
        raise DatasetError("Dataset has no data rows.")

    errors, warnings = [], []
    disc = pd.to_datetime(df[mapping["discovery_datetime"]], utc=True, errors="coerce", format="ISO8601")
    bad_dates = int(disc.isna().sum())
    if bad_dates == len(df):
        raise DatasetError("No record has a valid discovery_datetime; date filtering and drill-down are impossible.")
    if bad_dates:
        warnings.append(f"{bad_dates} record(s) have a missing or unparseable discovery_datetime; they are excluded "
                        "from date filtering and drill-down but remain in the dataset.")

    ids = df[mapping["case_id"]]
    dup_ids = int(ids.duplicated().sum())
    blank_ids = int((ids.isna() | (ids.str.strip() == "")).sum())
    if blank_ids:
        errors.append(f"{blank_ids} record(s) have a blank case_id.")
    if dup_ids:
        warnings.append(f"{dup_ids} duplicate case_id value(s); case detail lookups return the first match.")
    full_dupes = int(df.duplicated().sum())
    if full_dupes:
        warnings.append(f"{full_dupes} fully duplicated row(s).")

    if "ambient_temperature_c" in mapping:
        temp_raw = _num(df[mapping["ambient_temperature_c"]])
    else:
        temp_raw = pd.Series(np.nan, index=df.index)
    bad_temp = int(((temp_raw < TEMP_PLAUSIBLE[0]) | (temp_raw > TEMP_PLAUSIBLE[1])).sum())
    if bad_temp:
        warnings.append(f"{bad_temp} ambient temperature value(s) outside {TEMP_PLAUSIBLE[0]}..{TEMP_PLAUSIBLE[1]} °C are "
                        "excluded from temperature statistics (values are not altered).")
    temp = temp_raw.where((temp_raw >= TEMP_PLAUSIBLE[0]) & (temp_raw <= TEMP_PLAUSIBLE[1]))

    if "postmortem_interval_hours" in mapping:
        pmi_raw = _num(df[mapping["postmortem_interval_hours"]])
    else:
        pmi_raw = pd.Series(np.nan, index=df.index)
    bad_pmi = int((pmi_raw < 0).sum())
    if bad_pmi:
        warnings.append(f"{bad_pmi} negative postmortem_interval_hours value(s) are excluded from PMI statistics.")
    pmi = pmi_raw.where(pmi_raw >= 0)

    # chronological sanity checks (reported, never corrected)
    def _dt(key):
        if key not in mapping:
            return None
        return pd.to_datetime(df[mapping[key]], utc=True, errors="coerce", format="ISO8601")
    alive, obs = _dt("last_known_alive_datetime"), _dt("observation_datetime")
    if alive is not None and int((alive > disc).sum()):
        warnings.append(f"{int((alive > disc).sum())} record(s) have last_known_alive after discovery.")
    if obs is not None and int((obs < disc).sum()):
        warnings.append(f"{int((obs < disc).sum())} record(s) have observation before discovery.")
    for f in missing_fields:
        warnings.append(f"Optional column '{COLUMN_MAP[f]}' is absent; features that need it are disabled.")

    if errors:
        raise DatasetError("; ".join(errors))
    validation = {
        "valid": True, "errors": errors, "warnings": warnings,
        "undated_records": bad_dates, "duplicate_case_ids": dup_ids,
        "implausible_temperature_values": bad_temp, "negative_pmi_values": bad_pmi,
        "pmi_valid_count": int(pmi.notna().sum()),
    }
    return Dataset(
        df=df, mapping=mapping, missing_fields=missing_fields, disc=disc,
        year=disc.dt.year.astype("Int64"), month=disc.dt.month.astype("Int64"),
        temp=temp, pmi=pmi, validation=validation, columns_info=_col_info(df), file_name=file_name,
        loaded_at=pd.Timestamp.now(tz="UTC").isoformat(timespec="seconds"), mtime=mtime,
    )


def load_csv(path: Path) -> Dataset:
    if path.suffix.lower() != ".csv":
        raise DatasetError("DATASET_PATH must point to a .csv file.")
    if not path.is_file():
        raise DatasetError(f"Dataset file not found: {path.name}. Place it in backend/data/ or set DATASET_PATH.")
    try:
        df = pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    except Exception as exc:  # malformed CSV, encoding problems, permissions
        raise DatasetError(f"Dataset could not be read: {exc}") from exc
    df.columns = [c.strip() for c in df.columns]
    ds = build_dataset(df, file_name=path.name, mtime=path.stat().st_mtime)
    log.info("Loaded %s: %d rows, %d columns, %d warning(s)", path.name, len(df), len(df.columns), len(ds.validation["warnings"]))
    return ds


class DatasetStore:
    """Thread-safe lazy cache; reloads only when the file changes on disk."""

    def __init__(self, path: Path):
        self.path = path
        self._ds: Optional[Dataset] = None
        self._lock = threading.Lock()
        self.last_error: Optional[str] = None

    def get(self) -> Dataset:
        with self._lock:
            try:
                mtime = self.path.stat().st_mtime if self.path.is_file() else None
            except OSError:
                mtime = None
            if self._ds is None or mtime is None or self._ds.mtime != mtime:
                try:
                    self._ds = load_csv(self.path)
                    self.last_error = None
                except DatasetError as exc:
                    self._ds = None
                    self.last_error = str(exc)
                    log.error("Dataset unavailable: %s", exc)
                    raise
            return self._ds
