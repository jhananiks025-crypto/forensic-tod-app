"""Shared request dependencies: dataset access and filter parsing."""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import Depends, HTTPException, Query, Request

from ..services.dataset import Dataset, DatasetError, DatasetStore
from ..services.filters import Filters


def get_store(request: Request) -> DatasetStore:
    return request.app.state.store


def get_dataset(store: DatasetStore = Depends(get_store)) -> Dataset:
    try:
        return store.get()
    except DatasetError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


def get_filters(
    date_from: Optional[date] = Query(None, description="Start date YYYY-MM-DD, inclusive (UTC date of discovery_datetime)."),
    date_to: Optional[date] = Query(None, description="End date YYYY-MM-DD, inclusive."),
    year: Optional[int] = Query(None, ge=1000, le=9999, description="Discovery year (drill-down level 1)."),
    month: Optional[int] = Query(None, ge=1, le=12, description="Discovery month 1-12 (drill-down level 2)."),
    scene_type: Optional[str] = Query(None, max_length=64),
    location_category: Optional[str] = Query(None, max_length=64),
    data_quality_status: Optional[str] = Query(None, max_length=64),
    observation_source: Optional[str] = Query(None, max_length=64),
    temp_min: Optional[float] = Query(None, description="Ambient °C, inclusive lower bound."),
    temp_max: Optional[float] = Query(None, description="Ambient °C, EXCLUSIVE upper bound."),
    pmi_min: Optional[float] = Query(None, ge=0, description="PMI hours, inclusive lower bound."),
    pmi_max: Optional[float] = Query(None, ge=0, description="PMI hours, EXCLUSIVE upper bound."),
    q: Optional[str] = Query(None, max_length=64, description="Case-ID substring search."),
) -> Filters:
    # FilterError raised here is converted to HTTP 422 by the handler registered in main.py
    return Filters(date_from=date_from, date_to=date_to, year=year, month=month, scene_type=scene_type,
                   location_category=location_category, data_quality_status=data_quality_status,
                   observation_source=observation_source, temp_min=temp_min, temp_max=temp_max,
                   pmi_min=pmi_min, pmi_max=pmi_max, q=q).validate()
