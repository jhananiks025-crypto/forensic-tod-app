from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from ..schemas.common import Envelope
from ..services import analytics as svc
from ..services.dataset import Dataset
from ..services.filters import Filters
from .deps import get_dataset, get_filters

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/overview", response_model=Envelope)
def overview(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    """Summary-card figures for the filtered records."""
    return svc.overview(ds, f)


@router.get("/by-year", response_model=Envelope)
def by_year(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    """Case counts per discovery year. `year`/`month` are ignored here (they are drill-down state)."""
    return svc.by_year(ds, f)


@router.get("/by-month", response_model=Envelope)
def by_month(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    """12 months of `year` when given, otherwise a year-month timeline across the dataset span."""
    return svc.by_month(ds, f)


@router.get("/by-scene", response_model=Envelope)
def by_scene(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    return svc.by_scene(ds, f)


@router.get("/by-location", response_model=Envelope)
def by_location(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    return svc.by_location(ds, f)


@router.get("/temperature-distribution", response_model=Envelope)
def temperature_distribution(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    return svc.temperature_distribution(ds, f)


@router.get("/pmi-distribution", response_model=Envelope)
def pmi_distribution(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    """`data.available` is false (with a reason) when the dataset has no valid PMI labels."""
    return svc.pmi_distribution(ds, f)


@router.get("/data-quality", response_model=Envelope)
def data_quality(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    return svc.data_quality(ds, f)


@router.get("/drilldown", response_model=Envelope)
def drilldown(
    level: str = Query("year", description="year | month | cases"),
    page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=200),
    sort_by: str = Query("discovery_datetime"), sort_dir: str = Query("asc"),
    ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters),
):
    """Year -> month -> case-level drill-down. 'month' needs `year`; 'cases' needs `year` and `month`."""
    return svc.drilldown(ds, f, level, page, page_size, sort_by, sort_dir)
