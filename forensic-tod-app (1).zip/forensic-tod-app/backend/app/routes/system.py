from __future__ import annotations

from fastapi import APIRouter, Depends

from ..schemas.common import Health
from ..services import analytics
from ..services.dataset import Dataset, DatasetError, DatasetStore
from .deps import get_dataset, get_store

router = APIRouter(prefix="/api", tags=["system"])


@router.get("/health", response_model=Health)
def health(store: DatasetStore = Depends(get_store)):
    """Always answers 200 while the server is up; `status` is 'degraded' if the dataset cannot be loaded."""
    try:
        ds = store.get()
        return Health(status="ok", dataset_loaded=True, records=int(len(ds.df)), dataset_file=ds.file_name)
    except DatasetError as exc:
        return Health(status="degraded", dataset_loaded=False, error=str(exc))


@router.get("/dataset/summary")
def dataset_summary(ds: Dataset = Depends(get_dataset)):
    """Row/column counts, column mapping, per-column quality info, validation messages and dataset labelling."""
    return {"data": analytics.dataset_summary(ds)}
