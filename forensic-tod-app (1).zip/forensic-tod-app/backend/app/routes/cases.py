from __future__ import annotations

from fastapi import APIRouter, Depends, Path, Query, Response

from ..config import get_settings
from ..schemas.common import CaseEnvelope, Envelope
from ..services import analytics as svc
from ..services.dataset import Dataset
from ..services.filters import Filters
from .deps import get_dataset, get_filters

router = APIRouter(prefix="/api/cases", tags=["cases"])


@router.get("", response_model=Envelope)
def list_cases(
    page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=200),
    sort_by: str = Query("discovery_datetime"), sort_dir: str = Query("asc"),
    ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters),
):
    """Paginated, filtered, sortable case list (summary fields only)."""
    return svc.list_cases(ds, f, page, page_size, sort_by, sort_dir, get_settings().max_page_size)


@router.get("/export")
def export_cases(ds: Dataset = Depends(get_dataset), f: Filters = Depends(get_filters)):
    """CSV of the filtered case list (summary fields). Capped by MAX_EXPORT_ROWS."""
    text, _ = svc.export_cases_csv(ds, f, get_settings().max_export_rows)
    return Response(content=text, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="forensic-tod-cases.csv"'})


@router.get("/{case_id}", response_model=CaseEnvelope)
def get_case(case_id: str = Path(..., max_length=64), ds: Dataset = Depends(get_dataset)):
    return svc.get_case(ds, case_id)
