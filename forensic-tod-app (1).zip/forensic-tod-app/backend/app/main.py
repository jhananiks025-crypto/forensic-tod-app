"""FastAPI entry point.  Run from the backend/ folder:  uvicorn app.main:app --reload --port 8000"""
from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .config import get_settings
from .routes import analytics, cases, system
from .services.analytics import NotFoundError
from .services.dataset import DatasetError, DatasetStore
from .services.filters import FilterError

log = logging.getLogger("forensic_tod")


def create_app() -> FastAPI:
    settings = get_settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    store = DatasetStore(settings.dataset_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        try:
            store.get()  # warm the cache; the server still starts if the dataset is missing (health shows 'degraded')
        except DatasetError as exc:
            log.warning("Starting without a dataset: %s", exc)
        yield

    app = FastAPI(title="Forensic TOD Analytics API", version="1.0.0", lifespan=lifespan,
                  description="Descriptive analytics over the supplied historical-incident dataset. "
                              "No time-of-death prediction model is connected.")
    app.state.store = store
    app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_methods=["GET"], allow_headers=["*"])

    @app.exception_handler(FilterError)
    async def _filter_error(_: Request, exc: FilterError):
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.exception_handler(NotFoundError)
    async def _not_found(_: Request, exc: NotFoundError):
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    @app.exception_handler(DatasetError)
    async def _dataset_error(_: Request, exc: DatasetError):
        return JSONResponse(status_code=503, content={"detail": str(exc)})

    @app.middleware("http")
    async def _log_requests(request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        log.info("%s %s -> %s (%.0f ms)", request.method, request.url.path, response.status_code, (time.perf_counter() - start) * 1000)
        return response

    for r in (system.router, analytics.router, cases.router):
        app.include_router(r)
    return app


app = create_app()
